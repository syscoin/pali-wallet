/** Software-only entry: explicit host storage, no browser/device initialization. */
import { KeyringCore } from './keyring-core';
import type { KeyringHost, KeyringOptions } from './keyring-host';
import type { EncryptedEvmHdRuntimeAccount, EvmHdRuntimeAccountOptions, EvmHdRuntimeAccountRequest } from './software-hd-account';
import type { PreparedEvmSigningOptions, PreparedSoftwareEvmSigningRequest, SignedPreparedEvmTransaction } from './transactions/prepared-evm';
export declare class SoftwareKeyring extends KeyringCore<undefined, undefined> {
    constructor(host: KeyringHost, options: KeyringOptions);
    /**
     * Derive a fixed-path Ethereum HD runtime account without network or storage
     * writes. The returned password-encrypted xprv is internal runtime state,
     * never a public account/catalogue DTO. The host owns index allocation.
     */
    deriveEvmHdRuntimeAccount(request: EvmHdRuntimeAccountRequest, options: EvmHdRuntimeAccountOptions): Promise<EncryptedEvmHdRuntimeAccount>;
    /**
     * Sign exactly the prepared envelope without RPC, fee/nonce discovery or
     * broadcasting. The host must journal the result before submitting it.
     * A later lock cannot revoke already returned signed bytes.
     */
    signPreparedEvmTransaction(request: PreparedSoftwareEvmSigningRequest, options: PreparedEvmSigningOptions): SignedPreparedEvmTransaction;
    static createInitialized(host: KeyringHost, seed: string, password: string, vaultStateGetter: () => any, options: KeyringOptions): Promise<SoftwareKeyring>;
}
export { createKeyringHost } from './keyring-host';
export type { KeyringHost, KeyringOptions } from './keyring-host';
export { KeyringAccountType } from './types';
export { INetworkType } from '@sidhujag/sysweb3-network';
export type { INetwork } from '@sidhujag/sysweb3-network';
export type { DeviceUnlockControls, DeviceUnlockCredential, DeviceUnlockPort, DeviceUnlockVaultPair, KeyringStoragePort, } from './keyring-core';
export type { EvmRetainedCancellationOrigin, IKeyringAccountState, SyscoinOwnedReadOptions, SyscoinOwnedSubmissionOptions, SyscoinSubmissionDescriptor, } from './types';
export type { EvmAccessList, PreparedEvmTransaction, } from './transactions/evm-envelope';
export type { PreparedEvmSigningOptions, PreparedSoftwareEvmSigningRequest, SignedPreparedEvmTransaction, } from './transactions/prepared-evm';
export type { EncryptedEvmHdRuntimeAccount, EvmHdRuntimeAccountOptions, EvmHdRuntimeAccountRequest, } from './software-hd-account';
export { captureEvmSubmission, submitSignedEvmTransaction, evmSubmissionFailure, } from './transactions/evm-submission';
export type { CaptureEvmSubmission, EvmSubmissionContext, EvmSubmissionLifecycle, EvmSignedSubmission, EvmSubmissionBoundary, } from './transactions/evm-submission';
