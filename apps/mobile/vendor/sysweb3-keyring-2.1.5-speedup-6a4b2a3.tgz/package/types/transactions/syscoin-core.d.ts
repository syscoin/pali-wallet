import { ITxid } from '@sidhujag/sysweb3-utils';
import { Psbt } from 'bitcoinjs-lib';
import { ISyscoinTransactions, KeyringAccountType, accountType, type SyscoinOwnedReadOptions, type SyscoinOwnedSubmissionOptions, type SyscoinRetainedSubmissionOptions } from '../types';
import { ExcludedOutpoint } from '../utils/excluded-utxos';
import { type PsbtAccountScope } from '../utils/psbt-account-scope';
import type { SyscoinHDSigner } from '../signers';
import type { INetwork } from '@sidhujag/sysweb3-network';
/** A hardware operation receives only its selected public account/context. */
export interface ISyscoinHardwareSigningRequest {
    readonly account: Readonly<{
        id: number;
        xpub: string;
    }>;
    assertCurrent: () => void;
    getRawTransaction?: (txid: string) => Promise<unknown>;
    readonly network: Readonly<INetwork>;
    psbt: Psbt;
    scope: PsbtAccountScope;
    signal: AbortSignal;
}
/**
 * Trusted wallet-authority adapter, not an untrusted plugin entry point.
 * Implementations must preserve the reviewed unsigned transaction and enforce
 * device signature/account-scope validation before returning the signed PSBT.
 */
export type ISyscoinHardwareSigner = (request: ISyscoinHardwareSigningRequest) => Promise<Psbt>;
export interface ISyscoinHardwareSigners {
    ledger?: ISyscoinHardwareSigner;
    trezor?: ISyscoinHardwareSigner;
}
export declare const createHardwareSignerUnavailableError: (hardware: string) => Error & {
    code: string;
};
type BlockbookRead = Pick<SyscoinOwnedReadOptions, 'fetch' | 'signal'>;
/** Public network fee estimate. It has no wallet, account or signing access. */
export declare function readPublicSyscoinFee(explorerUrl: string, owner: SyscoinOwnedReadOptions): Promise<number>;
/** Internal captured context for the keyring's existing read-only builder and address lookup. */
export type SyscoinUtxoReadContext = Readonly<{
    assertCurrent: () => void;
    network: Readonly<INetwork>;
    transport: BlockbookRead;
    xpub: string;
}>;
type OwnedPreparation = Readonly<{
    account: Readonly<{
        address: string;
        xpub: string;
    }>;
    accountId: number;
    accountType: KeyringAccountType;
    read: SyscoinUtxoReadContext;
}>;
type GetUtxoReadState = () => {
    accounts: Partial<Record<KeyringAccountType, accountType>>;
    activeAccountId: number;
    activeAccountType: KeyringAccountType;
    activeNetwork: INetwork;
};
/** Bind both transaction preparation and address reads to the active wallet. */
export declare function captureOwnedSyscoinRead(options: SyscoinOwnedReadOptions, getState: GetUtxoReadState, captureSigningContext: (bindSessionRevision: boolean) => () => void): OwnedPreparation;
type GetUtxoAddress = (xpub: string, isChangeAddress: boolean) => Promise<string>;
type ReadOnlySigner = {
    main: any;
    getOwnedAddress?: GetUtxoAddress;
};
export declare class SyscoinTransactionsCore implements ISyscoinTransactions {
    private getSigner;
    private getReadOnlySigner;
    private hardwareSigners;
    private getState;
    private captureSigningContext;
    constructor(getSyscoinSigner: () => {
        hd: SyscoinHDSigner;
        main: any;
    }, getReadOnlySigner: (read?: SyscoinUtxoReadContext) => ReadOnlySigner, getState: () => {
        accounts: {
            HDAccount: accountType;
            Imported: accountType;
            Ledger: accountType;
            Trezor: accountType;
        };
        activeAccountId: number;
        activeAccountType: KeyringAccountType;
        activeNetwork: INetwork;
    }, hardwareSigners: ISyscoinHardwareSigners, captureSigningContext: (bindSessionRevision: boolean) => () => void);
    private getTransactionPSBT;
    decodeRawTransaction: (psbtOrHex: any, isRawHex?: boolean) => any;
    private captureOwnedRead;
    getRecommendedFee: (explorerUrl: string, ownedRead: SyscoinOwnedReadOptions) => Promise<number>;
    private signPSBTWithSigner;
    private createNativeSweepPSBT;
    private createUnsignedPSBT;
    private signPSBTWithMethod;
    getEstimateSysTransactionFee: ({ txOptions, isMax, nativeSweep, amount, receivingAddress, feeRate, token, excludedOutpoints, }: {
        amount: number | string;
        feeRate?: number;
        receivingAddress: string;
        token?: {
            guid: string;
            symbol?: string;
        } | null;
        txOptions?: any;
        isMax?: boolean | false;
        nativeSweep?: boolean;
        excludedOutpoints?: readonly ExcludedOutpoint[];
    }, ownedRead: SyscoinOwnedReadOptions) => Promise<{
        grossAmount?: string | undefined;
        recipientAmount?: string | undefined;
        fee: number;
        psbt: any;
    }>;
    signPSBT: ({ psbt }: {
        isLedger?: boolean;
        isTrezor?: boolean;
        psbt: any;
    }, ownedRead: SyscoinOwnedReadOptions) => Promise<any>;
    sendTransaction: (rawTransaction: string, authority: SyscoinOwnedSubmissionOptions) => Promise<ITxid>;
    /** Replay only the bytes and destination authenticated by the selected wallet. */
    replayRetainedTransaction: (txid: string, authority: SyscoinRetainedSubmissionOptions) => Promise<ITxid>;
}
export {};
