import { INetwork, INetworkType } from '@sidhujag/sysweb3-network';
import { IDecryptPrivateRecordParams, IEncryptedPrivateRecord, IEncryptPrivateRecordParams } from './private-records';
import { SyscoinHDSigner } from './signers';
import { type ISyscoinHardwareSigners } from './transactions/syscoin-core';
import { IKeyringAccountState, ICreateSmartAccountParams, ISyscoinTransactions, KeyringAccountType, IEthereumTransactions } from './types';
import type { LedgerKeyring } from './ledger';
import type { EncryptedEvmHdRuntimeAccount, EvmHdRuntimeAccountOptions, EvmHdRuntimeAccountRequest } from './software-hd-account';
import type { VaultPersistence, VaultStoragePort } from './storage-core';
import type { PreparedEvmSigningOptions, PreparedSoftwareEvmSigningRequest, SignedPreparedEvmTransaction } from './transactions/prepared-evm';
import type { TrezorKeyring } from './trezor';
/** Explicit asynchronous host storage; no browser or global DI fallback. */
export interface KeyringStoragePort extends VaultStoragePort {
    get(key: string): Promise<any>;
    deleteItem(key: string): Promise<void>;
    /** Legacy adapter capability; fixed native hosts can omit it. */
    setClient?(client: any): void;
}
/** Only the device capabilities consumed by the wallet authority. */
export interface KeyringLedgerSigner {
    destroy: LedgerKeyring['destroy'];
    evm: Pick<LedgerKeyring['evm'], 'getEvmAddressAndPubKey' | 'signTypedData' | 'signPersonalMessage' | 'signEVMTransaction'>;
    utxo: Pick<LedgerKeyring['utxo'], 'getXpub'>;
    verifyUtxoAddress: LedgerKeyring['verifyUtxoAddress'];
}
export type KeyringTrezorSigner = Pick<TrezorKeyring, 'destroy' | 'getAccountInfo' | 'getPublicKey' | 'signTypedData' | 'signMessage' | 'signEthTransaction' | 'verifyUtxoAddress'>;
export interface KeyringCoreDependencies<TLedger extends KeyringLedgerSigner | undefined, TTrezor extends KeyringTrezorSigner | undefined> {
    /** Immutable identity shared only by keyrings in the same wallet authority. */
    authority: object;
    storage: KeyringStoragePort;
    /** Must be bound to this authority's storage and shared across its keyrings. */
    vaultPersistence: VaultPersistence;
    ledgerSigner: TLedger;
    trezorSigner: TTrezor;
    /** Trusted host adapters; absent device capabilities fail closed. */
    syscoinHardwareSigners?: ISyscoinHardwareSigners;
}
export interface ISysAccount {
    address: string;
    label?: string;
    xprv?: string;
    xpub: string;
}
/**
 * Secure Buffer implementation for sensitive data
 * Provides explicit memory clearing capability
 */
declare class SecureBuffer {
    private buffer;
    private _isCleared;
    constructor(data: string | Buffer);
    get(): Buffer;
    toString(): string;
    clear(): void;
    isCleared(): boolean;
}
export declare class KeyringCore<TLedger extends KeyringLedgerSigner | undefined = KeyringLedgerSigner | undefined, TTrezor extends KeyringTrezorSigner | undefined = KeyringTrezorSigner | undefined> {
    trezorSigner: TTrezor;
    ledgerSigner: TLedger;
    initialTrezorAccountState: IKeyringAccountState;
    initialLedgerAccountState: IKeyringAccountState;
    utf8Error: boolean;
    ethereumTransaction: IEthereumTransactions;
    syscoinTransaction: ISyscoinTransactions;
    private readonly authority;
    private readonly storage;
    private readonly vaultPersistence;
    private readonly syscoinHardwareSigners;
    private getVaultState;
    setVaultStateGetter: (getter: () => any) => void;
    private getVault;
    private getActiveChain;
    private accountAddressExists;
    private sessionPassword;
    private sessionMnemonic;
    private privateRecordSessionRevision;
    constructor(dependencies: KeyringCoreDependencies<TLedger, TTrezor>);
    private createSyscoinTransactions;
    private requireLedgerSigner;
    private requireTrezorSigner;
    initialize(seed: string, password: string, network?: INetwork): Promise<IKeyringAccountState>;
    setStorage: (client: any) => void;
    validateAccountType: (account: IKeyringAccountState) => KeyringAccountType.HDAccount | KeyringAccountType.Imported;
    isUnlocked: () => boolean;
    lockWallet: () => Promise<void>;
    transferSessionTo: (targetKeyring: Pick<KeyringCore, "receiveSessionOwnership">) => void;
    private acceptSessionFrom;
    receiveSessionOwnership: (sessionPassword: SecureBuffer, sessionMnemonic: SecureBuffer) => void;
    private replaceSessionBuffers;
    addNewAccount: (label?: string) => Promise<IKeyringAccountState>;
    createSmartAccount: ({ address, deriveAccount, label, metadata, }: ICreateSmartAccountParams) => Promise<IKeyringAccountState>;
    /**
     * Returns canLogin:false only when the first vault authentication fails.
     * Storage, platform and session restoration failures reject so callers do
     * not charge a failed password attempt for an operational error.
     */
    unlock(password: string): Promise<{
        canLogin: boolean;
        needsAccountCreation?: boolean;
    }>;
    getNewChangeAddress: () => Promise<string>;
    getChangeAddress: (id: number) => Promise<string>;
    getPubkey: (id: number, isChangeAddress: boolean) => Promise<string>;
    getBip32Path: (id: number, isChangeAddress: boolean) => Promise<string>;
    updateReceivingAddress: () => Promise<string>;
    getAccountById: (id: number, accountType: KeyringAccountType) => Omit<IKeyringAccountState, "xprv">;
    getPrivateKeyByAccountId: (id: number, accountType: KeyringAccountType, pwd: string) => Promise<string>;
    getActiveAccount: () => {
        activeAccount: Omit<IKeyringAccountState, "xprv">;
        activeAccountType: KeyringAccountType;
    };
    private isDescriptor;
    private isXpubLike;
    private isWatchOnlyAccount;
    getEncryptedXprv: (hd: SyscoinHDSigner) => string;
    getSeed: (pwd: string) => Promise<any>;
    deriveSLHDSASetupSecretForAccount: ({ accountIndex, }: {
        accountIndex: number;
    }) => Promise<{
        derivationLabel: string;
        setupSecretHex: string;
    }>;
    encryptSLHDSASessionState: (plainText: string) => string;
    decryptSLHDSASessionState: (cipherText: string) => string;
    private privateRecordSession;
    /** Stable local profile identifier; never an account address or a key. */
    getPrivateRecordProfileId(): Promise<string>;
    /** Encrypt caller-owned bytes; persistence and encrypted backup belong to the caller. */
    encryptPrivateRecord(params: IEncryptPrivateRecordParams): Promise<IEncryptedPrivateRecord>;
    decryptPrivateRecord(params: IDecryptPrivateRecordParams): Promise<Uint8Array>;
    setSignerNetwork: (network: INetwork) => Promise<{
        activeChain?: INetworkType;
        success: boolean;
    }>;
    forgetMainWallet: (pwd: string) => Promise<void>;
    importWeb3Account: (mnemonicOrPrivKey: string) => import("./transactions/evm-local-signer").EvmLocalAccount;
    getAccountXpub: () => string;
    isSeedValid: (seedPhrase: string) => any;
    createNewSeed: (wordCount?: number) => any;
    getUTXOState: () => any;
    importTrezorAccount(label?: string): Promise<IKeyringAccountState<any>>;
    importLedgerAccount(label?: string): Promise<IKeyringAccountState<any>>;
    getActiveUTXOAccountState: () => any;
    getNetwork: () => any;
    createEthAccount: (privateKey: string) => import("./transactions/evm-local-signer").EvmLocalAccount;
    private fetchCurrentAccountData;
    getAddress: (xpub: string, isChangeAddress: boolean, options?: {
        forceIndex0?: boolean;
    }) => Promise<string>;
    getCurrentAddressPubkey: (xpub: string, isChangeAddress: boolean) => Promise<string>;
    getCurrentAddressBip32Path: (xpub: string, isChangeAddress: boolean) => Promise<string>;
    logout: () => void;
    importAccount(privKey: string, label?: string, options?: {
        utxoAddressType?: 'p2wpkh' | 'p2pkh' | 'p2tr';
    }): Promise<IKeyringAccountState<any>>;
    importWatchOnly(identifier: string, label?: string): Promise<IKeyringAccountState<any>>;
    validateZprv(zprv: string, targetNetwork?: INetwork): {
        isValid: boolean;
        node: any;
        network: {
            bip32: {
                public: number;
                private: number;
            };
            messagePrefix: string;
            bech32: string;
            pubKeyHash: any;
            scriptHash: any;
            slip44: any;
            wif: any;
        };
        message: string;
    } | {
        isValid: boolean;
        message: any;
        node?: undefined;
        network?: undefined;
    };
    validateWif(wif: string, targetNetwork?: INetwork): {
        isValid: boolean;
        message?: undefined;
    } | {
        isValid: boolean;
        message: any;
    };
    /**
     * PRIVATE METHODS
     */
    private getDecryptedPrivateKey;
    private capturePsbtSigningContext;
    /** Fixed-path derivation for an authenticated software host; no persistence. */
    protected deriveSoftwareEvmHdRuntimeAccount(input: EvmHdRuntimeAccountRequest, options: EvmHdRuntimeAccountOptions): Promise<EncryptedEvmHdRuntimeAccount>;
    /** The software facade owns this public capability; no device fallback. */
    protected signPreparedSoftwareEvmTransaction(input: PreparedSoftwareEvmSigningRequest, options: PreparedEvmSigningOptions): SignedPreparedEvmTransaction;
    private getSigner;
    private getReadOnlySigner;
    private writeUtf8Diagnostic;
    private validateAndHandleErrorByMessage;
    private getAccountsState;
    /**
     *
     * @param password
     * @param salt
     * @returns derived key: hex string
     */
    private encryptSHA512;
    private hasWebCrypto;
    private hexToBytes;
    private bytesToHex;
    private getEncIterations;
    private pbkdf2WebCryptoHex;
    private encryptSHA512Async;
    private deriveLegacySessionKey;
    private deriveStoredSessionKey;
    private getSysActivePrivateKey;
    private getInitialAccountData;
    private _createTrezorAccount;
    private _createLedgerAccount;
    private getFormattedBackendAccount;
    private setLatestIndexesFromXPubTokens;
    private createUTXOAccountAtIndex;
    private addNewAccountToSyscoinChain;
    private addNewAccountToEth;
    private getNextAccountId;
    private getBasicWeb3AccountInfo;
    private setDerivedWeb3Accounts;
    private setSignerEVM;
    private clearTemporaryLocalKeys;
    private recreateSessionFromVault;
    private _getPrivateKeyAccountInfos;
    /**
     * Common method to decrypt mnemonic from session
     * Eliminates code duplication across multiple methods
     */
    private getDecryptedMnemonic;
    /**
     * Creates network RPC config from current active network without making RPC calls
     * Common utility for all on-demand signer creation
     */
    private createNetworkRpcConfig;
    /**
     * Common signer creation logic - takes decrypted mnemonic/zprv and creates fresh signer
     * OPTIMIZED: No RPC call needed - uses network config directly
     */
    private createFreshUTXOSigner;
    /**
     * Creates a fresh UTXO signer for HD accounts derived from the main seed
     * OPTIMIZED: No RPC call needed - uses network config directly
     */
    private createOnDemandUTXOSigner;
    private isZprv;
    initializeSession: (seedPhrase: string, password: string) => Promise<void>;
    createFirstAccount: (label?: string) => Promise<IKeyringAccountState>;
    initializeWalletSecurely: (seedPhrase: string, password: string) => Promise<IKeyringAccountState>;
    private getSessionPasswordString;
    private getSessionMnemonicString;
    private withSecureData;
    private generateNetworkAwareLabel;
    /**
     * Clean up all resources
     */
    destroy(): Promise<void>;
}
export {};
