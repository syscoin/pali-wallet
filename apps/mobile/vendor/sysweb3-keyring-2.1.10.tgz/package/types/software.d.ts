/** Software-only entry: explicit host storage, no browser/device initialization. */
import { HostKeyring } from './host-keyring';
import type { KeyringHost, KeyringOptions } from './keyring-host';
export declare class SoftwareKeyring extends HostKeyring<undefined, undefined> {
    constructor(host: KeyringHost, options: KeyringOptions);
    static createInitialized(host: KeyringHost, seed: string, password: string, vaultStateGetter: () => any, options: KeyringOptions): Promise<SoftwareKeyring>;
}
export { createKeyringHost } from './keyring-host';
export type { KeyringHost, KeyringOptions } from './keyring-host';
export { KeyringAccountType } from './types';
export { INetworkType } from '@sidhujag/sysweb3-network';
export type { INetwork } from '@sidhujag/sysweb3-network';
export type { DeviceUnlockControls, DeviceUnlockCredential, DeviceUnlockPort, DeviceUnlockVaultPair, KeyringStoragePort, } from './keyring-core';
export type { EvmRetainedCancellationOrigin, IKeyringAccountState, SyscoinOwnedReadOptions, SyscoinOwnedSubmissionOptions, SyscoinSubmissionDescriptor, } from './types';
export type { EvmAccessList, PreparedEvmTransaction, } from './transactions/evm-envelope';
export type { PreparedEvmSigningOptions, PreparedSoftwareEvmSigningRequest, SignedPreparedEvmTransaction, } from './transactions/prepared-evm';
export type { EncryptedEvmHdRuntimeAccount, EvmHdRuntimeAccountOptions, EvmHdRuntimeAccountRequest, } from './software-hd-account';
export { captureEvmSubmission, submitSignedEvmTransaction, evmSubmissionFailure, } from './transactions/evm-submission';
export type { CaptureEvmSubmission, EvmSubmissionContext, EvmSubmissionLifecycle, EvmSignedSubmission, EvmSubmissionBoundary, } from './transactions/evm-submission';
