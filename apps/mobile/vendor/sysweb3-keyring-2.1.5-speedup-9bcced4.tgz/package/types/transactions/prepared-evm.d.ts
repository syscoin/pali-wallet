/**
 * Fully specified type-0/type-2 transaction. Quantities are canonical decimal
 * integer strings, nonce is at most MAX_SAFE_INTEGER, and gasLimit is uint64.
 * Addresses must be nonzero hex addresses; valid casing is normalized. Data is
 * even-length 0x hex, at most 16 KiB. Contract creation/access lists are omitted.
 */
export type PreparedEvmTransaction = Readonly<{
    from: string;
    to: string;
    chainId: string;
    nonce: string;
    value: string;
    gasLimit: string;
    data: string;
} & ({
    type: 0;
    gasPrice: string;
} | {
    type: 2;
    maxFeePerGas: string;
    maxPriorityFeePerGas: string;
})>;
export type PreparedSoftwareEvmSigningRequest = Readonly<{
    account: Readonly<{
        id: number;
        type: 'HDAccount' | 'Imported';
        expectedAddress: string;
    }>;
    network: Readonly<{
        kind: 'ethereum';
        chainId: string;
        slip44: 60;
        /** Exact configured endpoint binding; signing does not contact or authenticate it. */
        url: string;
    }>;
    transaction: PreparedEvmTransaction;
}>;
export type PreparedEvmSigningOptions = Readonly<{
    /** Host-owned consent/session/review expiry check. Must return undefined. */
    assertCurrent(): void;
}>;
export type SignedPreparedEvmTransaction = Readonly<{
    rawTransaction: string;
    hash: string;
    unsignedHash: string;
    from: string;
    /** Canonical signed fields, checked against the requested envelope. */
    transaction: PreparedEvmTransaction;
}>;
export declare function snapshotPreparedEvmRequest(input: unknown): PreparedSoftwareEvmSigningRequest;
export declare function preparedEvmGuard(input: unknown): () => void;
/** Internal, network-free signing. The key never becomes part of the result. */
export declare function signPreparedEvmEnvelope(transaction: PreparedEvmTransaction, privateKey: string): Readonly<{
    signed: SignedPreparedEvmTransaction;
    expectedUnsigned: string;
}>;
