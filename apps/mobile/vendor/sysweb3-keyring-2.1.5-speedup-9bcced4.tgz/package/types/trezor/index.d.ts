import { TypedMessage, SignTypedDataVersion, TypedDataV1 } from '@metamask/eth-sig-util';
import { Psbt } from 'bitcoinjs-lib';
import { Buffer } from 'buffer';
import type { HardwareTransactionAuthority } from '../hardware-transaction-authority';
import type { AccountInfo, EthereumTransaction, EthereumTransactionEIP1559 } from '@trezor/connect-webextension';
export interface TrezorControllerState {
    hdPath: string;
    paths: Record<string, number>;
}
declare global {
    interface Window {
        TrezorConnect: any;
    }
}
export declare class TrezorKeyring {
    hdPath: string;
    publicKey: Buffer;
    chainCode: Buffer;
    paths: Record<string, number>;
    model?: string;
    private hardwareWalletManager;
    private initialized;
    private lifecycleGeneration;
    private unsubscribeTrezor?;
    private readonly onTrezorConnected;
    private readonly onTrezorDisconnected;
    constructor();
    private observeTrezor;
    /**
     * Initialize Trezor script.
     */
    init(assertCurrent?: () => void): Promise<boolean>;
    /**
     * Execute operation with automatic retry
     */
    private executeWithRetry;
    /**
     * This return account info based in params provided.
     *
     * @param coin - network symbol. Example: eth, sys, btc
     * @param slip44 - network slip44 number
     * @param hdPath - path derivation. Example: m/84'/57'/0'
     * @param index - index of account for path derivation
     * @returns derivated account info or error
     */
    getAccountInfo({ coin, slip44, hdPath, index, }: {
        coin: string;
        hdPath?: string;
        index?: number;
        slip44: number;
    }): Promise<AccountInfo>;
    /**
     * Gets the model, if known.
     * This may be `undefined` if the model hasn't been loaded yet.
     *
     * @returns
     */
    getModel(): string | undefined;
    /**
     * This disposes the active Trezor Suite connection
     *
     * @returns void
     */
    dispose(): void;
    /**
     * This verify if message is valid or not.
     *
     * @param coin - network symbol. Example: eth, sys, btc
     * @param address - account address that signed message
     * @param message - message to be verified. Example: 'Test message'
     * @param signature - signature received in sign method. Example: I6BrpivjCwZmScZ6BMAHWGQPo+JjX2kzKXU5LcGVfEgvFb2VfJuKo3g6eSQcykQZiILoWNUDn5rDHkwJg3EcvuY=
     * @returns derivated account info or error
     */
    verifyMessage({ coin, address, message, signature, }: {
        address: string;
        coin: string;
        message: string;
        signature: string;
    }): Promise<{
        success: any;
        payload: any;
    }>;
    /**
     * This return account public key.
     *
     * @param coin - network symbol. Example: eth, sys, btc
     * @param slip44 - network slip44 number
     * @param hdPath - path derivation. Example: m/44'/57'/0'/0/0
     * @returns publicKey and chainCode
     */
    getPublicKey({ coin, slip44, hdPath, index, }: {
        coin: string;
        hdPath?: string;
        index?: number;
        slip44: number;
    }): Promise<any>;
    range(n: number): number[];
    /**
     * This sign UTXO tx.
     *
     * @param coin - network symbol. Example: eth, sys, btc
     * @param inputs - utxo transaction inputs
     * @param outputs - utxo transaction outputs
     * @returns signature object
     */
    signUtxoTransaction(utxoTransaction: any, psbt: Psbt, authority: HardwareTransactionAuthority): Promise<Psbt>;
    private setHdPath;
    convertToAddressNFormat(path: string): any[];
    isScriptHash(address: string, networkInfo: any): boolean;
    isPaymentFactory(payment: any): (script: any) => boolean;
    isBech32(address: string): boolean;
    isP2WSHScript(script: any): boolean;
    convertToTrezorFormat({ psbt, coin, network }: any): any;
    /**
     * This sign EVM tx.
     *
     * @param index - index of account for path derivation
     * @param tx - ethereum tx object
     * @returns signature object
     */
    signEthTransaction({ tx, index, coin, slip44, }: {
        index: string;
        tx: EthereumTransaction | EthereumTransactionEIP1559;
        coin: string;
        slip44: number;
    }, authority: HardwareTransactionAuthority): Promise<import("@trezor/connect-webextension").OkWithDevice<{
        authorizationList?: {
            address: string;
            chainId: number;
            r: string;
            s: string;
            nonce: number;
            yParity: number;
        }[] | undefined;
        r: string;
        s: string;
        v: string;
        serializedTx: string;
    }>>;
    /**
     * This sign message.
     *
     * @param coin - network symbol. Example: eth, sys, btc
     * @param slip44 - network slip44 number
     * @param message - message to be signed. Example: 'Test message'
     * @param index - index of account for path derivation
     * @returns signature object
     */
    signMessage({ index, message, coin, slip44, address, }: {
        address: string;
        coin: string;
        index?: number;
        message?: string;
        slip44: number;
    }): Promise<unknown>;
    private _signUtxoPersonalMessage;
    private _signEthPersonalMessage;
    private _sanitizeData;
    private _transformTypedData;
    /**
     * EIP-712 Sign Typed Data
     */
    signTypedData({ version, address, data, index, }: {
        address: string;
        data: TypedMessage<any> | TypedDataV1;
        index: number;
        version: SignTypedDataVersion;
    }): Promise<string>;
    /**
     * Verify UTXO address by displaying it on the Trezor device
     * @param accountIndex - The account index
     * @param currency - The currency (coin type)
     * @param slip44 - The slip44 value for the network
     * @returns The verified address
     */
    verifyUtxoAddress(accountIndex: number, currency: string, slip44: number): Promise<string | undefined>;
    /**
     * Check Trezor status
     */
    getStatus(): import("../hardware-wallet-manager").HardwareWalletStatus | undefined;
    /**
     * Clean up resources
     */
    destroy(): Promise<void>;
}
