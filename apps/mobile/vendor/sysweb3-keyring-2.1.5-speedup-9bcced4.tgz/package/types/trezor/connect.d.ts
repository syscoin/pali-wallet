import type { HardwareTransactionAuthority } from '../hardware-transaction-authority';
import type { ConnectDynamicSettings, TrezorConnectPublicAPI } from '@trezor/connect-webextension';
type Client = TrezorConnectPublicAPI<ConnectDynamicSettings>;
declare const methods: readonly ["getFeatures", "getAccountInfo", "ethereumGetAddress", "ethereumGetPublicKey", "getPublicKey", "getAddress", "signMessage", "ethereumSignMessage", "ethereumSignTypedData", "verifyMessage", "ethereumVerifyMessage"];
type ForwardedMethod = (typeof methods)[number];
type Compatible<T> = T extends {
    success: false;
} ? T & {
    payload: {
        error: string;
        code?: string;
    };
} : T;
type CompatibleCall<FunctionType> = FunctionType extends {
    (...args: infer A): infer R;
    (...args: infer B): infer S;
    (...args: infer C): infer T;
} ? {
    (...args: A): Promise<Compatible<Awaited<R>>>;
    (...args: B): Promise<Compatible<Awaited<S>>>;
    (...args: C): Promise<Compatible<Awaited<T>>>;
} : never;
type Calls = {
    [Name in ForwardedMethod]: CompatibleCall<Client[Name]>;
};
type ConnectionEvent = {
    type: 'disconnected';
} | {
    type: 'model';
    model: string;
};
export declare const subscribeTrezorEvents: (listener: (event: ConnectionEvent) => void) => (() => void);
declare const TrezorConnect: Calls & {
    ethereumSignTransactionOwned: (request: Parameters<Client['ethereumSignTransaction']>[0], authority: HardwareTransactionAuthority) => ReturnType<CompatibleCall<Client['ethereumSignTransaction']>>;
    signTransactionOwned: (request: Parameters<Client['signTransaction']>[0], authority: HardwareTransactionAuthority) => ReturnType<CompatibleCall<Client['signTransaction']>>;
    init: Client['init'];
    dispose: () => Promise<void>;
};
export declare const trezorResponseError: (response: {
    payload?: {
        error?: string;
        code?: string;
    };
}, prefix?: string) => Error;
export default TrezorConnect;
