import { ConnectionStatus, HardwareWalletType } from '../hardware-wallet-manager';
import type { HardwareWalletManager } from '../hardware-wallet-manager';
import type { LedgerHost, LedgerUtxoHost } from './host-types';
import type { IEvmMethods, IUTXOMethods } from './types';
/** Small authority-side facade. Device SDKs belong exclusively in ledger-host. */
export declare class LedgerKeyring {
    private readonly sharedHardwareWalletManager?;
    private readonly host?;
    readonly evm: IEvmMethods;
    readonly utxo: IUTXOMethods;
    private generation;
    constructor(sharedHardwareWalletManager?: HardwareWalletManager | undefined, host?: LedgerHost | undefined);
    private requireHost;
    private run;
    ensureConnection: () => Promise<void>;
    verifyUtxoAddress: (accountIndex: number, currency: string, slip44: number) => Promise<string>;
    signUtxoMessage: (request: Parameters<LedgerUtxoHost["signMessage"]>[0]) => Promise<string>;
    signPsbt: (request: Parameters<LedgerUtxoHost["signPsbt"]>[0], authority: Parameters<LedgerUtxoHost["signPsbt"]>[1]) => ReturnType<LedgerUtxoHost["signPsbt"]>;
    getStatus(): {
        type: HardwareWalletType;
        connected: boolean;
        status: ConnectionStatus;
    };
    destroy(): Promise<void>;
}
