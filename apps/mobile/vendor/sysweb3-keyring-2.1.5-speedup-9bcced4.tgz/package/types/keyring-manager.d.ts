import { HardwareWalletManager } from './hardware-wallet-manager';
import { KeyringCore } from './keyring-core';
import { LedgerKeyring } from './ledger';
import { TrezorKeyring } from './trezor';
import type { KeyringHost, KeyringOptions } from './keyring-host';
import type { LedgerHost } from './ledger/host-types';
import type { CaptureEvmSubmission } from './transactions/evm-submission';
import type { IKeyringManager } from './types';
export type { ISysAccount } from './keyring-core';
export type { DeviceUnlockControls, DeviceUnlockPort, DeviceUnlockVaultPair, KeyringStoragePort, } from './keyring-core';
export type KeyringManagerOptions = Omit<KeyringOptions, 'captureEvmSubmission'> & {
    captureEvmSubmission: CaptureEvmSubmission;
} & ({
    ledgerHost: LedgerHost;
    hardwareManager?: never;
} | {
    ledgerHost?: never;
    hardwareManager: HardwareWalletManager;
});
/** Browser keyring with an explicit wallet authority and hardware adapter. */
export declare class KeyringManager extends KeyringCore<LedgerKeyring, TrezorKeyring> implements IKeyringManager {
    constructor(host: KeyringHost, options: KeyringManagerOptions);
    static createInitialized(host: KeyringHost, seed: string, password: string, vaultStateGetter: () => any, options: KeyringManagerOptions): Promise<KeyringManager>;
}
