export type HardwareTransactionAuthority = Readonly<{
    assertCurrent: () => void;
    signal: AbortSignal;
}>;
export declare function captureHardwareTransactionAuthority(authority: HardwareTransactionAuthority): HardwareTransactionAuthority;
