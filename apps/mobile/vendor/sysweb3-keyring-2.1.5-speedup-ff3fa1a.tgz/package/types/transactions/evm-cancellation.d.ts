import type { planEvmCancellationFees } from '../evm-fees';
/** A host supplies the authenticated original identity and the captured fee plan. */
export type EvmCancellationEnvelopeIntent = Readonly<{
    payer: string;
    chainId: number | string;
    nonce: number | string;
    feePlan: ReturnType<typeof planEvmCancellationFees>;
}>;
/** Checks the exact unsigned bytes. Original eligibility and approval remain host checks. */
export declare function assertEvmCancellationEnvelope(unsigned: string, { payer, chainId, nonce, feePlan }: EvmCancellationEnvelopeIntent): void;
