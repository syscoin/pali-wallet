export interface EvmFeeReader {
    getGasPrice(): Promise<unknown>;
    getBlock(tag: 'latest'): Promise<{
        baseFeePerGas?: unknown;
    } | null>;
    send(method: 'eth_maxPriorityFeePerGas' | 'eth_feeHistory', params: unknown[]): Promise<unknown>;
    readonly signal?: AbortSignal;
}
export interface EvmFeeOptions {
    /** The host retains responsibility for chain, endpoint and account binding. */
    assertCurrent?: () => void;
    signal?: AbortSignal;
    minPriorityFee?: unknown;
    /** Positive, whole percentage; the existing recommendation uses 250. */
    feeMultiplier?: number;
}
export type EvmFeeData = Readonly<{
    gasPrice: bigint;
    /** Absent only when the observed header has no base-fee field. */
    baseFeePerGas?: bigint;
    maxFeePerGas: bigint;
    maxPriorityFeePerGas: bigint;
}>;
/** A validated limit failed its wire bounds or an activated protocol bound. */
export declare class EvmGasLimitError extends Error {
    readonly code: 'SYSWEB3_EVM_GAS_LIMIT_INVALID' | 'SYSWEB3_EVM_GAS_LIMIT_EXCEEDED';
    constructor(code: 'SYSWEB3_EVM_GAS_LIMIT_INVALID' | 'SYSWEB3_EVM_GAS_LIMIT_EXCEEDED');
}
/** The host supplies a verified chain and, if sampled, its block gas limit. */
export declare function assertEvmGasLimit(gasLimit: bigint, chainId: bigint, sampledBlockGasLimit?: bigint): bigint;
/** Accept the SDK's existing BigNumberish forms without permissive zero coercion. */
export declare function parseEvmFeeQuantity(value: unknown, label?: string): bigint;
/**
 * The existing successful-estimate policy: floor(estimate * 120 / 100), then
 * the configured minimum if larger. Callers retain chain/resource bounds.
 */
export declare function bufferedEvmGasLimit(estimate: bigint, minimum?: bigint): bigint;
export type EvmCancellationFeeInput = Readonly<{
    type: 0;
    currentGasPrice: bigint;
    originalGasPrice?: bigint;
} | {
    type: 2;
    currentMaxFeePerGas: bigint;
    currentMaxPriorityFeePerGas: bigint;
    originalMaxFeePerGas?: bigint;
    originalMaxPriorityFeePerGas?: bigint;
}>;
export declare const EVM_CANCELLATION_GAS_LIMIT = 42000n;
/** Plan only the cancellation fees. The host validates the rates and envelope. */
export declare function planEvmCancellationFees(input: EvmCancellationFeeInput): Readonly<{
    type: 0;
    gasLimit: 42000n;
    gasPrice: bigint;
    maximumFee: bigint;
}> | Readonly<{
    type: 2;
    gasLimit: 42000n;
    maxFeePerGas: bigint;
    maxPriorityFeePerGas: bigint;
    maximumFee: bigint;
}>;
export type EvmSpeedUpFeeInput = Readonly<{
    chainId: bigint;
    gasLimit: bigint;
    sampledBlockGasLimit: bigint;
    sampledBaseFeePerGas: bigint | null;
} & ({
    type: 0;
    gasPrice: bigint;
} | {
    type: 2;
    maxFeePerGas: bigint;
    maxPriorityFeePerGas: bigint;
})>;
/** Fee-only Speed Up policy. Hosts authenticate the original, own any zero-fee
 * fallback read, and supply the current sampled block limit and base fee. Type 0
 * describes legacy fee fields, including those of an admitted type 1 envelope.
 */
export declare function planEvmSpeedUpFees(input: EvmSpeedUpFeeInput): Readonly<{
    type: 0;
    gasLimit: bigint;
    gasPrice: bigint;
    maximumFee: bigint;
}> | Readonly<{
    type: 2;
    gasLimit: bigint;
    maxFeePerGas: bigint;
    maxPriorityFeePerGas: bigint;
    maximumFee: bigint;
}>;
/**
 * No signer, transport, network registry or provider implementation is imported.
 * Reads are serialized and guarded; RPC failures never become fabricated fees.
 */
export declare function getEvmFeeData(reader: EvmFeeReader, options?: EvmFeeOptions): Promise<EvmFeeData>;
