export interface ExcludedOutpoint {
    txid: string;
    vout: number;
}
export declare const excludedOutpointIds: (outpoints?: readonly ExcludedOutpoint[]) => Set<string>;
/** Preserve the backend's asset metadata while removing only reserved outputs. */
export declare const filterExcludedUtxos: (raw: any, excluded: ReadonlySet<string>, onExcluded?: (row: any, outpoint: string) => void) => any;
export declare const assertNoExcludedInputs: (psbt: {
    txInputs: {
        hash: Uint8Array;
        index: number;
    }[];
}, excluded: ReadonlySet<string>) => void;
