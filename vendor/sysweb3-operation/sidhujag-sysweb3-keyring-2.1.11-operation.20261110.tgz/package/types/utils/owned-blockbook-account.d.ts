import type { SyscoinOwnedReadOptions } from '../types';
/** Read address paths with the host's endpoint policy and independent lifetime. */
export declare function fetchOwnedBlockbookAccount(backendUrl: string, xpub: string, transport: Pick<SyscoinOwnedReadOptions, 'fetch' | 'signal'>): Promise<any>;
