/** Internal ciphertext comparison for a current-vault tag refusal. */
export declare const currentVaultRefusals: WeakMap<Error, (vault: string) => boolean>;
