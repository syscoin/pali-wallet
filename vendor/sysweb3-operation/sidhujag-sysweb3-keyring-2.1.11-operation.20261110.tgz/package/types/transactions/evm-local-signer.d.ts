import ecc from '@bitcoinerlab/secp256k1';
import { type Deferrable, type TransactionRequest } from '../ethers-v6';
import { CustomJsonRpcProvider } from '../providers';
import { type EvmSubmissionBoundary } from './evm-submission';
export type EvmLocalAccount = {
    address: string;
    privateKey: string;
    publicKey: string;
};
export declare const normalizePrivateKey: (privateKey: string | Uint8Array) => Buffer<ArrayBufferLike>;
export declare const privateKeyToAccount: (privateKey: string | Uint8Array) => EvmLocalAccount;
export declare const deriveEvmAccountFromMnemonic: (mnemonic: string, derivationPath: string) => EvmLocalAccount;
export declare const signDigest: (digest: string | Uint8Array, privateKey: string | Uint8Array) => {
    r: string;
    s: string;
    recoveryParam: ecc.RecoveryIdType;
    v: number;
};
export declare const signDigestHex: (digest: string | Uint8Array, privateKey: string | Uint8Array) => string;
export declare const hashPersonalMessage: (message: Uint8Array) => string;
export declare const signPersonalMessage: (message: string | Uint8Array, privateKey: string | Uint8Array) => string;
export declare const parsePersonalMessage: (hexMessage: string) => string;
/** Pin the checked gas and chain to the same detached envelope that is serialized. */
export declare const normalizeGasLimitedTransaction: (transaction: TransactionRequest) => TransactionRequest;
export declare const signTransaction: (transaction: TransactionRequest, privateKey: string | Uint8Array) => string;
export declare const sendLocalEvmTransaction: (provider: CustomJsonRpcProvider, privateKey: string, transaction: Deferrable<Record<string, any>>, beforeBroadcast: (() => void) | undefined, beforeSign: (() => void) | undefined, 
/** Synchronous final-envelope check; throw to reject. Promise results are rejected. */
validateBeforeSign: ((transaction: TransactionRequest) => void) | undefined, submission: EvmSubmissionBoundary) => Promise<unknown>;
export declare const sameAddress: (left: string, right: string) => boolean;
