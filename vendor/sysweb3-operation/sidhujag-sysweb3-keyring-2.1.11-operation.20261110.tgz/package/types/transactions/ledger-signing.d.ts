import type { HardwareTransactionAuthority } from '../hardware-transaction-authority';
import type { IEvmMethods } from '../ledger/types';
/** Sign the reviewed bytes through the shared Ledger adapter without changing fees or nonce. */
export declare function signLedgerEvmTransaction(signer: {
    evm: Pick<IEvmMethods, 'signEVMTransaction'>;
}, request: Readonly<{
    accountIndex: number;
    expectedAddress: string;
    unsignedTransaction: string;
}>, authority: HardwareTransactionAuthority): Promise<Readonly<{
    rawTransaction: string;
    hash: string;
}>>;
