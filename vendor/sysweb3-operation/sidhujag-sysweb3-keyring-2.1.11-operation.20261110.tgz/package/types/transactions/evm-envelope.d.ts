export type EvmAccessList = readonly Readonly<{
    address: string;
    storageKeys: readonly string[];
}>[];
/**
 * Fully specified type-0/type-2 transaction. Quantities are canonical decimal
 * integer strings, nonce is at most MAX_SAFE_INTEGER, and gasLimit is uint64.
 * The sender is a nonzero hex address. A null destination creates a contract.
 * Data is even-length 0x hex, at most 512 KiB. Type 2 requires an access list.
 */
export type PreparedEvmTransaction = Readonly<{
    from: string;
    to: string | null;
    chainId: string;
    nonce: string;
    value: string;
    gasLimit: string;
    data: string;
} & ({
    type: 0;
    gasPrice: string;
} | {
    type: 2;
    maxFeePerGas: string;
    maxPriorityFeePerGas: string;
    accessList: EvmAccessList;
})>;
/** Snapshot values without invoking accessors or accepting hidden fields. */
/** @internal Strict own-data snapshot shared with prepared request binding. */
export declare function readEvmOwnData(value: unknown, keys: readonly string[]): Record<string, unknown>;
/** Copy bounded own data while preserving the signed order and duplicates. */
export declare function snapshotEvmAccessList(value: unknown): EvmAccessList;
export declare function snapshotPreparedEvmTransaction(input: unknown): PreparedEvmTransaction;
/** @internal The same validated fields feed unsigned serialization and signing. */
export declare function prepareUnsignedEvmEnvelope(input: PreparedEvmTransaction): {
    transaction: PreparedEvmTransaction;
    unsigned: {
        gasPrice: bigint;
        type: 0 | 2;
        to: string | null;
        chainId: bigint;
        nonce: number;
        value: bigint;
        gasLimit: bigint;
        data: string;
    } | {
        maxFeePerGas: bigint;
        maxPriorityFeePerGas: bigint;
        accessList: {
            address: string;
            storageKeys: string[];
        }[];
        type: 0 | 2;
        to: string | null;
        chainId: bigint;
        nonce: number;
        value: bigint;
        gasLimit: bigint;
        data: string;
    };
    expectedUnsigned: string;
};
/** Validate and serialize the exact envelope used by prepared signing. */
export declare function serializePreparedEvmTransaction(transaction: PreparedEvmTransaction): string;
