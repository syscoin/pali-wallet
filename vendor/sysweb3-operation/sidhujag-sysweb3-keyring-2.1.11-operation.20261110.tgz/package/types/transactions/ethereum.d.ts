import { TypedMessage, SignTypedDataVersion, TypedDataV1 } from '@metamask/eth-sig-util';
import { INetwork } from '@sidhujag/sysweb3-network';
import { BigNumber, TransactionResponse } from '../ethers-v6';
import { type EvmFeeReader } from '../evm-fees';
import { CustomJsonRpcProvider } from '../providers';
import { IResponseFromSendErcSignedTransaction, ISendSignedErc20TransactionProps, ISendSignedErc721TransactionProps, ISendSignedErc1155TransactionProps, IReviewedEvmTokenApproval, IEthereumTransactions, IEvmCancellationOptions, IEvmReplacementOptions, EvmFormattedSendArguments, SimpleTransactionRequest, KeyringAccountType, accountType, IGasParams } from '../types';
import { type PreparedEvmTransaction } from './evm-envelope';
import { type CaptureEvmSubmission } from './evm-submission';
import { type HardwareTransactionAuthority } from '../hardware-transaction-authority';
import { type EvmDigestSignOptions, type PreparedSoftwareEvmSigningRequest, type PreparedEvmSigningOptions } from './prepared-evm';
import type { LedgerKeyring } from '../ledger';
import type { TrezorKeyring } from '../trezor';
/** Minimal trusted device capabilities used by EVM transaction routing. */
export interface EthereumLedgerSigner {
    evm: Pick<LedgerKeyring['evm'], 'signTypedData' | 'signPersonalMessage' | 'signEVMTransaction'>;
    verifyUtxoAddress: LedgerKeyring['verifyUtxoAddress'];
}
export type EthereumTrezorSigner = Pick<TrezorKeyring, 'signTypedData' | 'signMessage' | 'signEthTransaction' | 'verifyUtxoAddress'>;
export declare class EthereumTransactions<TLedger extends EthereumLedgerSigner | undefined = LedgerKeyring, TTrezor extends EthereumTrezorSigner | undefined = TrezorKeyring> implements IEthereumTransactions {
    private _web3Provider;
    private _web3ProviderKey?;
    trezorSigner: TTrezor;
    ledgerSigner: TLedger;
    private getNetwork;
    private readonly captureSigningContext;
    private readonly captureSubmissionLifecycle;
    private abortController;
    private getDecryptedPrivateKey;
    private gasOverrides;
    private getState;
    constructor(getNetwork: () => INetwork, getDecryptedPrivateKey: (targetAccount?: IEvmReplacementOptions['targetAccount']) => {
        address: string;
        decryptedPrivateKey: string;
    }, getState: () => {
        accounts: {
            HDAccount: accountType;
            Imported: accountType;
            Ledger: accountType;
            Trezor: accountType;
        };
        activeAccountId: number;
        activeAccountType: KeyringAccountType;
        activeNetwork: INetwork;
    }, ledgerSigner: TLedger, trezorSigner: TTrezor, captureSigningContext: () => () => void, captureSubmissionLifecycle: CaptureEvmSubmission | null);
    private requireLedgerSigner;
    private requireTrezorSigner;
    private assertHardwareSignerAvailable;
    private captureSessionGuard;
    private captureEvmAccountContext;
    private captureEvmSigningContext;
    private captureSubmission;
    private authorizeHardwareTransaction;
    private submitSignedHardwareTransaction;
    get web3Provider(): CustomJsonRpcProvider;
    private ensureProvidersInitialized;
    private captureMessageSigning;
    signTypedData: (addr: string, typedData: TypedDataV1 | TypedMessage<any>, version: SignTypedDataVersion, authority: HardwareTransactionAuthority) => Promise<string>;
    verifyUtxoAddress: (accountIndex: number, currency: string, slip44: number) => Promise<string | undefined>;
    verifyTypedSignature: (data: TypedDataV1 | TypedMessage<any>, signature: string, version: SignTypedDataVersion) => string;
    signPreparedEvmTransaction(input: PreparedSoftwareEvmSigningRequest, options: PreparedEvmSigningOptions): Readonly<{
        rawTransaction: string;
        hash: string;
        unsignedHash: string;
        from: string;
        transaction: PreparedEvmTransaction;
    }>;
    ethSign: (params: string[], input: EvmDigestSignOptions) => Promise<string>;
    signPersonalMessage: (params: string[], authority: HardwareTransactionAuthority) => Promise<string>;
    parsePersonalMessage: (hexMsg: string) => string;
    verifyPersonalMessage: (message: string, sign: string) => string;
    getEncryptedPubKey: () => string;
    decryptMessage: (msgParams: string[]) => string;
    toBigNumber: (aBigNumberish: string | number) => BigNumber;
    private toHex0x;
    private captureReviewedTokenApproval;
    private reviewedTokenFees;
    getData: ({ contractAddress, receivingAddress, value, }: {
        contractAddress: string;
        receivingAddress: string;
        value: any;
    }) => string;
    getFeeDataWithDynamicMaxPriorityFeePerGas: (provider?: EvmFeeReader) => Promise<{
        maxFeePerGas: BigNumber;
        maxPriorityFeePerGas: BigNumber;
        baseFeePerGas?: BigNumber | undefined;
        gasPrice: BigNumber;
    }>;
    calculateNewGasValues: (oldTxsParams: IGasParams, isForCancel: boolean, isLegacy: boolean, bounds: Readonly<{
        chainId: bigint;
        retainedCancellationGasLimit?: bigint;
        sampledBlockGasLimit: bigint;
        sampledBaseFeePerGas: bigint | null;
    }>) => IGasParams;
    cancelSentTransaction: (txHash: string, isLegacy: boolean | undefined, fallbackNonce: number | undefined, options: IEvmCancellationOptions) => Promise<{
        error?: boolean;
        isCanceled: boolean;
        transactionNotBroadcast?: boolean;
        signedTransactionHash?: string;
        maximumFee?: string;
        transaction?: TransactionResponse;
    }>;
    sendFormattedTransaction: (...args: EvmFormattedSendArguments) => Promise<unknown>;
    private sendFormattedTransactionInternal;
    sendTransactionWithEditedFee: (txHash: string, isLegacy: boolean | undefined, options: IEvmReplacementOptions) => Promise<{
        maximumFee?: string;
        error?: boolean;
        isSpeedUp: boolean;
        transactionNotBroadcast?: boolean;
        signedTransactionHash?: string;
        transaction?: TransactionResponse;
        code?: string;
        message?: string;
    }>;
    sendSignedErc20Transaction: (request: ISendSignedErc20TransactionProps, approval: IReviewedEvmTokenApproval) => Promise<IResponseFromSendErcSignedTransaction>;
    sendSignedErc721Transaction: (request: ISendSignedErc721TransactionProps, approval: IReviewedEvmTokenApproval) => Promise<IResponseFromSendErcSignedTransaction>;
    sendSignedErc1155Transaction: (request: ISendSignedErc1155TransactionProps, approval: IReviewedEvmTokenApproval) => Promise<IResponseFromSendErcSignedTransaction>;
    getRecommendedNonce: (address: string) => Promise<number>;
    getFeeByType: (type: string) => Promise<string>;
    getGasLimit: (toAddress: string) => Promise<number>;
    getTxGasLimit: (tx: SimpleTransactionRequest) => Promise<BigNumber>;
    getRecommendedGasPrice: (formatted?: boolean) => Promise<string | {
        gwei: string;
        ethers: string;
    }>;
    getBalance: (address: string) => Promise<number>;
    setWeb3Provider(network: INetwork): void;
    importAccount: (mnemonicOrPrivKey: string) => import("./evm-local-signer").EvmLocalAccount;
    setGasOverrides(overrides: {
        minGasLimit?: string | BigNumber;
        minPriorityFee?: string | BigNumber;
        feeMultiplier?: number;
    }): void;
    getGasOverrides(): {
        minGasLimit?: BigNumber;
        minPriorityFee?: BigNumber;
        feeMultiplier?: number;
    };
    getSafeFeeData: (forceLegacy?: boolean) => Promise<{
        gasPrice: BigNumber;
        maxFeePerGas: undefined;
        maxPriorityFeePerGas: undefined;
    } | {
        gasPrice: undefined;
        maxFeePerGas: BigNumber;
        maxPriorityFeePerGas: BigNumber;
    }>;
}
