import type { PreparedEvmTransaction } from './evm-envelope';
export type EvmSigningIdentity = Readonly<{
    id: number;
    type: 'HDAccount' | 'Imported' | 'Ledger' | 'Trezor' | 'SmartAccount';
    expectedAddress: string;
}>;
export declare function snapshotEvmSigningIdentity(input: unknown): EvmSigningIdentity;
export type EvmDigestSignOptions = Readonly<{
    signal: AbortSignal;
    selectedAccount: EvmSigningIdentity;
    targetAccount: EvmSigningIdentity;
    assertCurrent(): void;
}>;
export type PreparedSoftwareEvmSigningRequest = Readonly<{
    selectedAccount: EvmSigningIdentity;
    account: Readonly<{
        id: number;
        type: 'HDAccount' | 'Imported';
        expectedAddress: string;
    }>;
    network: Readonly<{
        kind: 'ethereum';
        chainId: string;
        slip44: 60;
        /** Exact configured endpoint binding; signing does not contact or authenticate it. */
        url: string;
    }>;
    transaction: PreparedEvmTransaction;
}>;
export type PreparedEvmSigningOptions = Readonly<{
    /** Host-owned consent/session/review expiry check. Must return undefined. */
    assertCurrent(): void;
}>;
export type SignedPreparedEvmTransaction = Readonly<{
    rawTransaction: string;
    hash: string;
    unsignedHash: string;
    from: string;
    /** Canonical signed fields, checked against the requested envelope. */
    transaction: PreparedEvmTransaction;
}>;
export declare function snapshotPreparedEvmRequest(input: unknown): PreparedSoftwareEvmSigningRequest;
export declare function preparedEvmGuard(input: unknown): () => void;
/** Internal, network-free signing. The key never becomes part of the result. */
export declare function signPreparedEvmEnvelope(input: PreparedEvmTransaction, privateKey: string): Readonly<{
    signed: SignedPreparedEvmTransaction;
    expectedUnsigned: string;
}>;
