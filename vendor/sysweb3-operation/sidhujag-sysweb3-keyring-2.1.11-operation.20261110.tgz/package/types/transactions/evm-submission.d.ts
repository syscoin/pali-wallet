import { Transaction } from 'ethers/transaction';
export { copyEvmSubmissionFailure, evmSubmissionFailure, } from './evm-submission-failure';
import type { EvmRetainedCancellationOrigin, EvmWalletNonce } from '../types';
export type EvmSubmissionContext = Readonly<{
    account: Readonly<{
        id: number;
        type: string;
        address: string;
    }>;
    network: Readonly<{
        kind: string;
        chainId: number;
        slip44: number;
        url: string;
    }>;
    operation: 'send' | 'cancel' | 'speed-up' | 'erc20' | 'erc721' | 'erc1155';
    originalHash?: string;
    origin?: EvmRetainedCancellationOrigin;
    /** Transient identity of the live host fee review, bound to these signed bytes. */
    review?: Readonly<{
        id: string;
        unsignedHash: string;
    }>;
    walletNonce?: EvmWalletNonce;
}>;
/** Signed wire bytes only; never a key, password or mutable transaction request. */
export type EvmSignedSubmission = Readonly<{
    context: EvmSubmissionContext;
    rawTransaction: string;
    hash: string;
    from: string;
    chainId: string;
    nonce: number;
    type: number | null;
}>;
/** The transport calls this after preflight, immediately around synchronous wire initiation. */
export type AdmitEvmSignedDispatch<T> = (initiate: () => Promise<T>, preflight?: () => Promise<void>) => Promise<T>;
export type EvmSignedBroadcast<T> = (request: Readonly<{
    rawTransaction: string;
    admit: AdmitEvmSignedDispatch<T>;
}>) => Promise<T>;
export type EvmSubmissionLifecycle = Readonly<{
    /** Synchronous host wallet/session/revision check, including A -> B -> A. */
    assertCurrent: () => void;
    /** Resolve only after durable acknowledgement. A rejection never dispatches. */
    persistSigned: (record: EvmSignedSubmission) => Promise<void>;
    /** Admit the exact retained record, releasing the owner before the remote response. */
    dispatchSigned: <T>(record: EvmSignedSubmission, initiate: () => Promise<T>, preflight: () => Promise<void>) => Promise<T>;
}>;
export type CaptureEvmSubmission = (context: EvmSubmissionContext) => EvmSubmissionLifecycle;
declare const evmSubmissionBrand: unique symbol;
export type EvmSubmissionBoundary = Readonly<{
    [evmSubmissionBrand]: true;
    context: EvmSubmissionContext;
    assertCurrent: () => void;
    persistSigned: (record: EvmSignedSubmission) => Promise<void>;
    dispatchSigned: EvmSubmissionLifecycle['dispatchSigned'];
}>;
/** Capture once, before RPC or device work. Never reread host capabilities later. */
export declare function captureEvmSubmission(input: EvmSubmissionContext, assertCurrent: () => void, capture: CaptureEvmSubmission): EvmSubmissionBoundary;
/** Refuse any new signature or dispatch without a captured durable port. */
export declare function assertDurableEvmSubmission(boundary: EvmSubmissionBoundary): void;
/** Compare signed wire bytes with the complete envelope captured before signing. */
export declare function assertSignedEvmTransactionMatches(rawTransaction: string, expectedUnsignedTransaction: string, expectedFrom?: string): Transaction;
/** Submit software-signed bytes through the captured durable boundary. */
export declare function submitSignedEvmTransaction<T>(rawTransaction: string, broadcast: EvmSignedBroadcast<T>, boundary: EvmSubmissionBoundary, beforeBroadcast: (() => void) | undefined, expectedUnsignedTransaction: string): Promise<T>;
/** @internal Device signatures always require a fresh live chain probe after persistence. */
export declare function submitSignedHardwareEvmTransaction<T>(rawTransaction: string, broadcast: EvmSignedBroadcast<T>, boundary: EvmSubmissionBoundary, beforeBroadcast: (() => void) | undefined, expectedUnsignedTransaction: string, verifyCurrentChain: () => Promise<void>): Promise<T>;
