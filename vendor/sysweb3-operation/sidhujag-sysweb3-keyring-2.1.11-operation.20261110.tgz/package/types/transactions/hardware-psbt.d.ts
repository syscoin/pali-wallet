import { type ISyscoinHardwareSigner } from './syscoin-core';
import type { LedgerKeyring } from '../ledger';
import type { TrezorKeyring } from '../trezor';
/** The software transaction engine never imports this device adapter. */
export declare function createLedgerPsbtSigner(ledger: LedgerKeyring): ISyscoinHardwareSigner;
/** Keep Trezor conversion and signing outside the software-only import graph. */
export declare function createTrezorPsbtSigner(trezor: TrezorKeyring): ISyscoinHardwareSigner;
