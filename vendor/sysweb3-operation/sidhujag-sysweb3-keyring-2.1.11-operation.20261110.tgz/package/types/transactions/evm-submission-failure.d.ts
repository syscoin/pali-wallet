type EvmSubmissionFailure = Readonly<{
    transactionNotBroadcast: boolean;
    signedTransactionHash?: string;
}>;
/** Return owned stage evidence only; unrecognized errors carry no classification. */
export declare function evmSubmissionFailure(error: unknown): EvmSubmissionFailure | undefined;
/** Preserve local evidence when an existing public API wraps its Error object. */
export declare function copyEvmSubmissionFailure(source: unknown, target: Error): void;
/** Internal callers supply observed stage facts, never provider error fields. */
export declare function annotateEvmSubmissionFailure(cause: unknown, observed: EvmSubmissionFailure): Error;
export {};
