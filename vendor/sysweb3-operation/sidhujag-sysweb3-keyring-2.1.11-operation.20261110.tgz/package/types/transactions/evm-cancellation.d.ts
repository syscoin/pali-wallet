import type { planEvmCancellationFees } from '../evm-fees';
import type { EvmRetainedCancellationOrigin } from '../types';
/** A host supplies the authenticated original identity and the captured fee plan. */
export type EvmCancellationEnvelopeIntent = Readonly<{
    payer: string;
    chainId: number | string;
    nonce: number | string;
    feePlan: ReturnType<typeof planEvmCancellationFees>;
}>;
/** Verify the selected signed bytes and snapshot the host's exact fee floor. */
export declare function authenticateRetainedCancellation(origin: EvmRetainedCancellationOrigin, hash: string, payer: string, chainId: number): EvmRetainedCancellationOrigin;
/** Checks the exact unsigned bytes. Original eligibility and approval remain host checks. */
export declare function assertEvmCancellationEnvelope(unsigned: string, { payer, chainId, nonce, feePlan }: EvmCancellationEnvelopeIntent): void;
