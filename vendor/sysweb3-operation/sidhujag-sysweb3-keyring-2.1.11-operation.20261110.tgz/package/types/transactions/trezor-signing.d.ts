import type { HardwareTransactionAuthority } from '../hardware-transaction-authority';
import type { TrezorKeyring } from '../trezor';
/** Sign reviewed bytes through an explicitly hosted Trezor keyring. */
export declare function signTrezorEvmTransaction(signer: Pick<TrezorKeyring, 'signEthTransaction'>, request: Readonly<{
    accountIndex: number;
    coin: string;
    expectedAddress: string;
    slip44: number;
    unsignedTransaction: string;
}>, authority: HardwareTransactionAuthority): Promise<Readonly<{
    rawTransaction: string;
    hash: string;
}>>;
