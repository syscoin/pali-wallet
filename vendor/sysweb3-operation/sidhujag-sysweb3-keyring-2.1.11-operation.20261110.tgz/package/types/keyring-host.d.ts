import type { DeviceUnlockControls, DeviceUnlockPort, KeyringStoragePort } from './keyring-core';
import type { VaultPersistence } from './storage-core';
import type { CaptureEvmSubmission } from './transactions/evm-submission';
declare const keyringHostBrand: unique symbol;
/** Opaque identity for one fixed wallet store and its unlock session. */
export interface KeyringHost {
    readonly [keyringHostBrand]: true;
}
export type SessionOwner = {
    current?: symbol;
    epoch: number;
};
type BoundHost = {
    storage: KeyringStoragePort;
    vaultPersistence: VaultPersistence;
    sessionOwner: SessionOwner;
    deviceUnlockPort?: DeviceUnlockPort;
};
export declare function createKeyringHost(storage: KeyringStoragePort, options?: {
    deviceUnlock?: DeviceUnlockPort;
}): KeyringHost;
export type SecretLifetimePolicy = 'session' | 'operation';
export type KeyringOptions = {
    /** Session is the existing extension policy. Mobile must explicitly select operation. */
    secretLifetime?: SecretLifetimePolicy;
    captureEvmSubmission: CaptureEvmSubmission | null;
    receiveDeviceUnlock?(controls: DeviceUnlockControls): void;
};
declare const bindingBrand: unique symbol;
export interface KeyringHostBinding {
    readonly [bindingBrand]: true;
}
type PreparedHost = Omit<BoundHost, 'deviceUnlockPort'> & {
    authority: KeyringHost;
    captureEvmSubmission: CaptureEvmSubmission | null;
    secretLifetime: SecretLifetimePolicy;
    deviceUnlock?: {
        port: DeviceUnlockPort;
        receive(controls: DeviceUnlockControls): void;
    };
};
export declare function takeKeyringHostBinding(binding: KeyringHostBinding): PreparedHost;
export declare function prepareKeyringHost(host: KeyringHost, options: KeyringOptions): {
    binding: KeyringHostBinding;
    publishControls?: undefined;
} | {
    binding: KeyringHostBinding;
    publishControls(): void;
};
export {};
