import { type LedgerDmkHost } from './dmk-host';
import type { LedgerEvmConfig } from './host-types';
/** A platform-owned transport and explicit user selection are required. */
export declare function createSelectedLedgerDmkHost(config: LedgerEvmConfig & {
    dmk: object;
}): LedgerDmkHost;
export type { LedgerDmkHost } from './dmk-host';
