import { type LedgerOperationOptions } from './host-types';
import type { DeviceManagementKit } from '@ledgerhq/device-management-kit';
import type { Observable } from 'rxjs';
type Action<Output> = {
    observable: Observable<{
        status: 'not-started' | 'stopped';
    } | {
        status: 'pending';
        intermediateValue: {
            requiredUserInteraction: string;
            step?: string;
        };
    } | {
        status: 'completed';
        output: Output;
    } | {
        status: 'error';
        error: unknown;
    }>;
    cancel(): void;
};
export interface LedgerDmkOperation {
    readonly dmk: DeviceManagementKit;
    readonly sessionId: string;
    readonly generation: number;
    readonly signal: AbortSignal;
    assertCurrent(): void;
    runAction<Output>(createAction: () => Action<Output>): Promise<Output>;
}
/** One owner and one semantic operation at a time, across EVM and UTXO apps. */
export declare class LedgerDmkSession {
    readonly dmk: DeviceManagementKit;
    private requireDeviceSelection;
    private generation;
    private connection;
    private queue;
    private activeCancel;
    private activeAbort;
    private closing;
    private closingResult;
    private readonly closeObservers;
    private stateSubscription;
    private connectionAttempt;
    private connectionAbort;
    private deviceSelection;
    private readonly invalidationListeners;
    private readonly statusListeners;
    private reportedConnected;
    constructor(dmk: DeviceManagementKit, requireDeviceSelection?: boolean);
    private get readyConnection();
    getStatus(): {
        connected: boolean;
    };
    subscribeStatus(listener: () => void): () => void;
    private publishStatus;
    onInvalidated(listener: () => void): () => void;
    private invalidate;
    /** The platform passes one candidate from its own current DMK picker. */
    beginDeviceSelection(signal?: AbortSignal): (candidate: object) => Promise<void>;
    /** Device selection belongs to the visible host, never to a dapp request. */
    connect(request?: {
        useGrantedDevices?: boolean;
    }, options?: LedgerOperationOptions): Promise<void>;
    private connectionBusy;
    private startConnection;
    private discoverDevice;
    private connectDevice;
    /** Cancel revokes the result and closes I/O; it cannot undo on-device approval. */
    disconnect(): Promise<void>;
    private closeSession;
    /** Join late vendor admission and its cleanup after immediate revocation. */
    retire(): Promise<() => void>;
    runExclusive<Output>(operation: (session: LedgerDmkOperation) => Promise<Output>, options?: LedgerOperationOptions): Promise<Output>;
    runAction<Output>(createAction: (session: LedgerDmkOperation) => Action<Output>, options?: LedgerOperationOptions): Promise<Output>;
    private awaitAction;
}
export {};
