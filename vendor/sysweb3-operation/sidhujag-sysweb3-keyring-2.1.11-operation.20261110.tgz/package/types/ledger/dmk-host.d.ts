import { type LedgerEvmConfig, type LedgerHost } from './host-types';
export interface LedgerDmkHost extends LedgerHost {
    /** Observe connection changes; read getStatus() in the callback. */
    subscribeStatus(listener: () => void): () => void;
    /** Start before enumerating. The returned capability is single use. */
    beginDeviceSelection(signal?: AbortSignal): (candidate: object) => Promise<void>;
}
/** Shared implementation; the default browser host supplies its own transport. */
export declare function createLedgerHostForDmk(candidate: object, config: LedgerEvmConfig, requireDeviceSelection?: boolean): LedgerDmkHost;
