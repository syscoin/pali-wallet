import type { IEncryptedPrivateRecord } from './private-records';
/** Public state is supplied as one canonical, immutable host manifest. */
export type PublicSessionCheckpointRequest = Readonly<{
    walletBindingId: string;
    publicState: Uint8Array;
    recordDomains: readonly string[];
}>;
export type PublicSessionRestoreRequest = PublicSessionCheckpointRequest & Readonly<{
    checkpoint: IEncryptedPrivateRecord;
}>;
export declare const MAX_PUBLIC_SESSION_STATE_BYTES: number;
export declare function capturePublicSessionRequest(input: PublicSessionCheckpointRequest): PublicSessionCheckpointRequest;
export declare function capturePublicSessionCheckpoint(input: PublicSessionRestoreRequest): IEncryptedPrivateRecord;
export declare function publicSessionStateDigest(state: Uint8Array, guard: () => void): Promise<Uint8Array>;
