/** Versioned, public envelope. Application metadata belongs inside the plaintext. */
export interface IEncryptedPrivateRecord {
    ciphertext: string;
    domain: string;
    nonce: string;
    profileId: string;
    recordId: string;
    version: 1;
}
export interface IEncryptPrivateRecordParams {
    domain: string;
    plaintext: Uint8Array;
    recordId: string;
}
export interface IDecryptPrivateRecordParams {
    domain: string;
    envelope: IEncryptedPrivateRecord;
    recordId: string;
}
export interface PrivateRecordAccessOptions {
    /** Move this grant with trusted public-session transfer; otherwise transfer retires it. */
    transferable: boolean;
}
export interface IPrivateRecordAccess {
    getPrivateRecordProfileId(): Promise<string>;
    encryptPrivateRecord(params: IEncryptPrivateRecordParams): Promise<IEncryptedPrivateRecord>;
    decryptPrivateRecord(params: IDecryptPrivateRecordParams): Promise<Uint8Array>;
    dispose(): void;
}
export declare const MAX_PRIVATE_RECORD_BYTES: number;
export declare const MAX_PRIVATE_RECORD_LABEL_BYTES = 128;
type Guard = () => void;
export declare function privateRecordProfileId(secret: Uint8Array, guard: Guard): Promise<string>;
export declare function encryptPrivateRecordBytes(secret: Uint8Array, params: IEncryptPrivateRecordParams, guard: Guard): Promise<IEncryptedPrivateRecord>;
export declare function decryptPrivateRecordBytes(secret: Uint8Array, params: IDecryptPrivateRecordParams, guard: Guard): Promise<Uint8Array>;
/** Canonical exact set, used only to retrieve a previously granted capability. */
export declare function privateRecordDomainSet(domains: readonly string[]): string;
/** Internal cache inspection; key material is never returned. */
export declare function activePrivateRecordDomainSet(access: IPrivateRecordAccess, authority: object): string | null;
/** Internal transfer policy; callers cannot upgrade an existing grant. */
export declare function privateRecordAccessCanTransfer(access: IPrivateRecordAccess, authority: object): boolean;
/** Internal trusted SDK transfer. Old methods/dispose cannot affect the moved keys. */
export declare function transferPrivateRecordAccess(access: IPrivateRecordAccess, sourceAuthority: object, targetAuthority: object, guard: Guard): IPrivateRecordAccess;
/** Derive only the named record keys, then release the root. No key export or derivation surface escapes. */
export declare function createPrivateRecordAccess(secret: Uint8Array, domains: readonly string[], options: PrivateRecordAccessOptions, guard: Guard, authority: object): Promise<IPrivateRecordAccess>;
export {};
