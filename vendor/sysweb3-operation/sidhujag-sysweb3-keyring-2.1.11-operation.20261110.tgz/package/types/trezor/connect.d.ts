import type { HardwareTransactionAuthority } from '../hardware-transaction-authority';
import type { TrezorCalls, TrezorHost, TrezorMethod } from './host-types';
type Client = TrezorCalls;
type TransactionMethod = 'ethereumSignTransaction' | 'signTransaction';
type SigningMethod = TransactionMethod | 'signMessage' | 'ethereumSignMessage' | 'ethereumSignTypedData';
type ForwardedMethod = Exclude<TrezorMethod, SigningMethod>;
type Compatible<T> = T extends {
    success: false;
} ? T & {
    payload: {
        error: string;
        code?: string;
    };
} : T;
type CompatibleCall<FunctionType> = FunctionType extends {
    (...args: infer A): infer R;
    (...args: infer B): infer S;
    (...args: infer C): infer T;
} ? {
    (...args: A): Promise<Compatible<Awaited<R>>>;
    (...args: B): Promise<Compatible<Awaited<S>>>;
    (...args: C): Promise<Compatible<Awaited<T>>>;
} : never;
type Calls = {
    [Name in ForwardedMethod]: CompatibleCall<Client[Name]>;
};
export type ConnectionEvent = {
    type: 'disconnected';
} | {
    type: 'model';
    model: string;
};
export type TrezorSigningSession = {
    [Name in SigningMethod]: CompatibleCall<Client[Name]>;
} & {
    init(): Promise<void>;
    dispose(): Promise<void>;
    getFeatures: CompatibleCall<Client['getFeatures']>;
};
export type TrezorConnection = Calls & {
    withOwnedSigning<Result>(authority: HardwareTransactionAuthority, operation: (session: TrezorSigningSession) => Promise<Result>): Promise<Result>;
    ethereumSignTransactionOwned: (request: Parameters<Client['ethereumSignTransaction']>[0], authority: HardwareTransactionAuthority) => ReturnType<CompatibleCall<Client['ethereumSignTransaction']>>;
    signTransactionOwned: (request: Parameters<Client['signTransaction']>[0], authority: HardwareTransactionAuthority) => ReturnType<CompatibleCall<Client['signTransaction']>>;
    init: () => Promise<void>;
    dispose: () => Promise<void>;
    retire: () => Promise<() => void>;
    subscribe(listener: (event: ConnectionEvent) => void): () => void;
};
export declare function createTrezorConnection(host: TrezorHost): TrezorConnection;
export declare const trezorResponseError: (response: {
    payload?: {
        error?: string;
        code?: string;
    };
}, prefix?: string) => Error;
export {};
