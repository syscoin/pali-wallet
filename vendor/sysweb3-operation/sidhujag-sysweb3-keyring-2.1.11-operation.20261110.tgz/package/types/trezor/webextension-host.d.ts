import type { TrezorHost } from './host-types';
import type { ConnectDynamicSettings, TrezorConnectPublicAPI } from '@trezor/connect-webextension';
type Client = TrezorConnectPublicAPI<ConnectDynamicSettings>;
export type TrezorWebExtensionSettings = Parameters<Client['init']>[0];
/** Explicit browser composition. The shared signer never loads this module. */
export declare function createTrezorWebExtensionHost(settings: TrezorWebExtensionSettings): TrezorHost;
export {};
