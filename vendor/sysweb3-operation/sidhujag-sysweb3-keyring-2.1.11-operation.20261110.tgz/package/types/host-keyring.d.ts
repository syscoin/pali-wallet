import { KeyringCore } from './keyring-core';
import type { KeyringHardware, KeyringLedgerSigner, KeyringTrezorSigner } from './keyring-core';
import type { KeyringHost, KeyringOptions } from './keyring-host';
import type { EncryptedEvmHdRuntimeAccount, EvmHdRuntimeAccountOptions, EvmHdRuntimeAccountRequest } from './software-hd-account';
import type { PreparedEvmSigningOptions, PreparedSoftwareEvmSigningRequest, SignedPreparedEvmTransaction } from './transactions/prepared-evm';
/** Shared wallet engine with explicit host authority and hardware capabilities. */
export declare class HostKeyring<TLedger extends KeyringLedgerSigner | undefined, TTrezor extends KeyringTrezorSigner | undefined> extends KeyringCore<TLedger, TTrezor> {
    constructor(host: KeyringHost, options: KeyringOptions, createHardware: () => KeyringHardware<TLedger, TTrezor>);
    /** Derive runtime state using the shared software account implementation. */
    deriveEvmHdRuntimeAccount(request: EvmHdRuntimeAccountRequest, options: EvmHdRuntimeAccountOptions): Promise<EncryptedEvmHdRuntimeAccount>;
    /** Sign the prepared software envelope; the host retains it before broadcast. */
    signPreparedEvmTransaction(request: PreparedSoftwareEvmSigningRequest, options: PreparedEvmSigningOptions): SignedPreparedEvmTransaction;
}
export { createKeyringHost } from './keyring-host';
export type { KeyringHost, KeyringOptions } from './keyring-host';
export type { KeyringHardware, KeyringLedgerSigner, KeyringTrezorSigner, PreparedSessionTransfer, } from './keyring-core';
export type { SecretOperationCredentialPort, SecretOperationOptions, } from './keyring-core';
export type { SecretLifetimePolicy } from './keyring-host';
export type { PublicSessionCheckpointRequest, PublicSessionRestoreRequest, } from './public-session';
export { MAX_PUBLIC_SESSION_STATE_BYTES } from './public-session';
