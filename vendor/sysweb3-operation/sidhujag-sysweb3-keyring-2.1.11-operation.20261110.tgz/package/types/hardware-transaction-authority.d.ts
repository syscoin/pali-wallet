export type HardwareTransactionAuthority = Readonly<{
    assertCurrent: () => void;
    signal: AbortSignal;
}>;
export declare function assertHardwareOperationCurrent(check: () => void): void;
export declare function captureHardwareTransactionAuthority(authority: HardwareTransactionAuthority): HardwareTransactionAuthority;
