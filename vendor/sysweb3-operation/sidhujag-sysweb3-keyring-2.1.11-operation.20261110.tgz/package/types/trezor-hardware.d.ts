import { TrezorKeyring } from './trezor';
import type { KeyringHardware } from './keyring-core';
import type { TrezorHost } from './trezor/host-types';
/** Use the same Trezor account and transaction adapters on every host. */
export declare function createTrezorHardware(host: TrezorHost): KeyringHardware<undefined, TrezorKeyring>;
export type { TrezorHost } from './trezor/host-types';
