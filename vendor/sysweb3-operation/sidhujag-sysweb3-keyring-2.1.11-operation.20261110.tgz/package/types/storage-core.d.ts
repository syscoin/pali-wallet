/** A host-owned namespace containing one wallet authority's logical records. */
export interface VaultStoragePort {
    get(key: string): Promise<unknown>;
    set(key: string, value: unknown): Promise<void>;
    /** Atomically creates the entire batch only when every key is absent. */
    createManyIfAbsent(items: Record<string, unknown>): Promise<boolean>;
}
export interface VaultPersistence {
    setEncryptedVault(decryptedVault: any, pwd: string, freshVaultKeys?: {
        salt: string;
    }, assertCurrent?: () => void): Promise<void>;
    getDecryptedVault(pwd: string, legacyPassword?: string): Promise<any>;
}
export declare class VaultAuthenticationError extends Error {
    readonly code = "INVALID_PASSWORD";
    constructor();
}
/** Authenticate a captured current-format vault. This path has no CBC fallback. */
export declare const decryptCurrentVault: (vault: string, key: string) => Promise<unknown>;
/**
 * Create once per wallet authority and share across its network keyrings.
 * The host owns storage durability and cross-context atomic creation.
 */
export declare const createVaultPersistence: (storage: VaultStoragePort) => VaultPersistence;
