/** Own a bounded signing payload before initialization or platform code can await. */
export declare function captureHardwareSigningData(value: unknown, invalid: () => Error): any;
