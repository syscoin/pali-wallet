import { LedgerKeyring } from './ledger';
import type { KeyringHardware } from './keyring-core';
import type { LedgerHost } from './ledger/host-types';
/** Use the same Ledger account and transaction adapters on every host. */
export declare function createLedgerHardware(host: LedgerHost): KeyringHardware<LedgerKeyring, undefined>;
