import type { IKeyringAccountState } from './types';
/** Fixed Ethereum BIP44 address index; not an arbitrary derivation path. */
export interface EvmHdRuntimeAccountRequest {
    readonly index: number;
}
/** Trusted host guard must return undefined synchronously. */
export interface EvmHdRuntimeAccountOptions {
    assertCurrent: () => void;
}
/**
 * Internal runtime record, matching createFirstAccount/addNewAccount. Contains a
 * password-encrypted xprv; never publish it or persist it as a public catalogue.
 * No plaintext private key, mnemonic, or password is returned.
 */
export type EncryptedEvmHdRuntimeAccount = IKeyringAccountState;
export declare function snapshotEvmHdIndex(value: EvmHdRuntimeAccountRequest): number;
