import { type LedgerDmkHost } from './ledger/dmk-host';
import type { LedgerEvmConfig } from './ledger/host-types';
export interface LedgerDmkHostConfig extends LedgerEvmConfig {
    /** Platform-owned DMK, allowing a future host to register its own transports. */
    dmk?: object;
    /** Disable automatic discovery until the platform selects a device. */
    requireDeviceSelection?: boolean;
}
export declare function createLedgerDmkHost(config?: LedgerDmkHostConfig): LedgerDmkHost;
export type { LedgerDmkHost } from './ledger/dmk-host';
export type { LedgerEvmConfig, LedgerBlindSigningIntent, LedgerHost, LedgerEvmHost, LedgerUtxoHost, LedgerUtxoAccount, LedgerPartialSignature, LedgerTypedData, LedgerOperationOptions, LedgerProgress, } from './ledger/host-types';
