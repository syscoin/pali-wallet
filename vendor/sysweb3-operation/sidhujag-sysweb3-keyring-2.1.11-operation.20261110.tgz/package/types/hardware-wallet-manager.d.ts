import { EventEmitter } from 'events';
import { HardwareWalletType } from './hardware-wallet-types';
import type { HardwareWalletStatus } from './hardware-wallet-types';
import type { LedgerHost } from './ledger/host-types';
import type { TrezorConnection, TrezorSigningSession } from './trezor/connect';
interface RetryConfig {
    maxRetries: number;
    baseDelay: number;
    maxDelay: number;
    backoffMultiplier: number;
}
/**
 * Hardware Wallet Manager with connection pooling, status monitoring, and error recovery
 */
export declare class HardwareWalletManager extends EventEmitter {
    private readonly ledgerHost?;
    private readonly trezor?;
    private connectionPool;
    private statusMonitorInterval;
    private unsubscribeTrezor?;
    private lifecycleGeneration;
    private trezorInitialization?;
    private destruction?;
    private ledgerInitialization?;
    private readonly IDLE_TIMEOUT;
    private readonly STATUS_CHECK_INTERVAL;
    private readonly retryConfig;
    constructor(ledgerHost?: LedgerHost | undefined, trezor?: TrezorConnection | undefined);
    private observeTrezor;
    private requireTrezor;
    /** Raw transports are deliberately unavailable through the semantic host boundary. */
    getLedgerConnection(): Promise<never>;
    private initializeLedger;
    /**
     * Initialize Trezor with retry logic
     */
    initializeTrezor(): Promise<boolean>;
    initializeTrezorOwned(session: TrezorSigningSession, assertCurrent: () => void): Promise<boolean>;
    private initializeTrezorInternal;
    /**
     * Initialize Trezor with exponential backoff retry
     */
    private initializeTrezorWithRetry;
    /**
     * Handle device disconnect
     */
    private handleDisconnect;
    /**
     * Start real-time status monitoring
     */
    private startStatusMonitoring;
    /**
     * Check all connections and clean up idle ones
     */
    private checkAllConnections;
    /**
     * Get current status of all hardware wallets
     */
    getStatus(): HardwareWalletStatus[];
    /**
     * Check if a specific device is connected
     */
    isConnected(type: HardwareWalletType): boolean;
    /**
     * Ensure connection before operation
     */
    ensureConnection(type: HardwareWalletType): Promise<void>;
    /**
     * Close a specific connection
     */
    private closeConnection;
    /**
     * Close all connections and stop monitoring
     */
    destroy(): Promise<void>;
    /**
     * Calculate exponential backoff delay
     */
    private calculateBackoffDelay;
    /**
     * Delay helper
     */
    private delay;
    /**
     * Retry an operation with exponential backoff
     */
    retryOperation<T>(operation: () => Promise<T>, operationName: string, customRetryConfig?: Partial<RetryConfig>): Promise<T>;
    /**
     * Detects common user-cancellation errors to avoid pointless retries
     */
    private isUserCancellationError;
}
export {};
