import { getAddress } from 'ethers/address';
import { keccak256 } from 'ethers/crypto';
import { JsonRpcProvider, type Networkish } from 'ethers/providers';
import { dataSlice, hexlify, isHexString, type BytesLike } from 'ethers/utils';
export { JsonRpcProvider, getAddress, dataSlice, hexlify, isHexString, keccak256, type BytesLike, type Networkish, };
export type TransactionRequest = Record<string, any>;
export type TransactionResponse = any;
export declare const Contract: any;
export type BigNumberish = bigint | number | string | BigNumberCompat | {
    _hex?: string;
    hex?: string;
    toString?: () => string;
};
export type Deferrable<T> = {
    [K in keyof T]: T[K] | Promise<T[K]>;
};
export declare class BigNumberCompat {
    readonly _isBigNumber = true;
    readonly value: bigint;
    private constructor();
    static from(value: BigNumberish | null | undefined): BigNumberCompat;
    static isBigNumber(value: unknown): value is BigNumberCompat;
    get _hex(): string;
    get hex(): string;
    add(value: BigNumberish): BigNumberCompat;
    sub(value: BigNumberish): BigNumberCompat;
    mul(value: BigNumberish): BigNumberCompat;
    div(value: BigNumberish): BigNumberCompat;
    eq(value: BigNumberish): boolean;
    lt(value: BigNumberish): boolean;
    gt(value: BigNumberish): boolean;
    isZero(): boolean;
    isNegative(): boolean;
    toBigInt(): bigint;
    toNumber(): number;
    toHexString(): string;
    toString(): string;
    toJSON(): {
        type: string;
        hex: string;
    };
}
export { BigNumberCompat as BigNumber };
export declare const Zero: BigNumberCompat;
export declare const parseUnits: (value: string, unit?: string | number) => BigNumberCompat;
export declare const parseEther: (value: string) => BigNumberCompat;
export declare const formatUnits: (value: BigNumberish, unit?: string | number) => string;
export declare const formatEther: (value: BigNumberish) => string;
export declare const resolveProperties: <T extends Record<string, any>>(value: Deferrable<T>) => Promise<T>;
export declare const shallowCopy: <T extends Record<string, any>>(value: T) => T;
export declare const toQuantityHex: (value: BigNumberish) => string;
export declare const normalizeTxValue: (value: any) => any;
export declare const normalizeTransactionRequest: (tx: Record<string, any>) => {
    [x: string]: any;
};
export declare const serializeTransaction: (tx: Record<string, any>, signature?: {
    r: string;
    s: string;
    v?: number;
    recoveryParam?: number;
}) => string;
export declare const arrayify: (value: BytesLike) => Buffer<ArrayBuffer>;
export declare const hexZeroPad: (value: BytesLike, length: number) => string;
export declare const joinSignature: (signature: {
    r: string;
    s: string;
    v?: number;
    recoveryParam?: number;
}) => string;
