import ecc from '@bitcoinerlab/secp256k1';
import { type Deferrable, type TransactionRequest } from '../ethers-v6';
import { CustomJsonRpcProvider } from '../providers';
export type EvmLocalAccount = {
    address: string;
    privateKey: string;
    publicKey: string;
};
export declare const normalizePrivateKey: (privateKey: string | Uint8Array) => Buffer<ArrayBufferLike>;
export declare const privateKeyToAccount: (privateKey: string | Uint8Array) => EvmLocalAccount;
export declare const deriveEvmAccountFromMnemonic: (mnemonic: string, derivationPath: string) => EvmLocalAccount;
export declare const signDigest: (digest: string | Uint8Array, privateKey: string | Uint8Array) => {
    r: string;
    s: string;
    recoveryParam: ecc.RecoveryIdType;
    v: number;
};
export declare const signDigestHex: (digest: string | Uint8Array, privateKey: string | Uint8Array) => string;
export declare const hashPersonalMessage: (message: Uint8Array) => string;
export declare const signPersonalMessage: (message: string | Uint8Array, privateKey: string | Uint8Array) => string;
export declare const parsePersonalMessage: (hexMessage: string) => string;
export declare const signTransaction: (transaction: TransactionRequest, privateKey: string | Uint8Array) => string;
export declare const sendLocalEvmTransaction: (provider: CustomJsonRpcProvider, privateKey: string, transaction: Deferrable<Record<string, any>>, beforeBroadcast?: () => void, beforeSign?: () => void, 
/** Synchronous final-envelope check; throw to reject. Promise results are rejected. */
validateBeforeSign?: (transaction: TransactionRequest) => void) => Promise<any>;
export declare const sameAddress: (left: string, right: string) => boolean;
