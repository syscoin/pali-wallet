import { ITxid, txUtils } from '@sidhujag/sysweb3-utils';
import { Psbt } from 'bitcoinjs-lib';
import { ISyscoinTransactions, KeyringAccountType, accountType } from '../types';
import { ExcludedOutpoint } from '../utils/excluded-utxos';
import { type PsbtAccountScope } from '../utils/psbt-account-scope';
import type { SyscoinHDSigner } from '../signers';
import type { INetwork } from '@sidhujag/sysweb3-network';
/** A hardware operation receives only its selected public account/context. */
export interface ISyscoinHardwareSigningRequest {
    readonly account: Readonly<{
        id: number;
        xpub: string;
    }>;
    assertCurrent: () => void;
    getRawTransaction?: ReturnType<typeof txUtils>['getRawTransaction'];
    readonly network: Readonly<INetwork>;
    psbt: Psbt;
    scope: PsbtAccountScope;
}
/**
 * Trusted wallet-authority adapter, not an untrusted plugin entry point.
 * Implementations must preserve the reviewed unsigned transaction and enforce
 * device signature/account-scope validation before returning the signed PSBT.
 */
export type ISyscoinHardwareSigner = (request: ISyscoinHardwareSigningRequest) => Promise<Psbt>;
export interface ISyscoinHardwareSigners {
    ledger?: ISyscoinHardwareSigner;
    trezor?: ISyscoinHardwareSigner;
}
export declare const createHardwareSignerUnavailableError: (hardware: string) => Error & {
    code: string;
};
export declare class SyscoinTransactionsCore implements ISyscoinTransactions {
    private getSigner;
    private getReadOnlySigner;
    private hardwareSigners;
    private getState;
    private getAddress;
    private captureSigningContext?;
    constructor(getSyscoinSigner: () => {
        hd: SyscoinHDSigner;
        main: any;
    }, getReadOnlySigner: () => {
        main: any;
    }, getState: () => {
        accounts: {
            HDAccount: accountType;
            Imported: accountType;
            Ledger: accountType;
            Trezor: accountType;
        };
        activeAccountId: number;
        activeAccountType: KeyringAccountType;
        activeNetwork: INetwork;
    }, getAddress: (xpub: string, isChangeAddress: boolean) => Promise<string>, hardwareSigners?: ISyscoinHardwareSigners, captureSigningContext?: () => () => void);
    private getTransactionPSBT;
    decodeRawTransaction: (psbtOrHex: any, isRawHex?: boolean) => any;
    private feeCache;
    getRecommendedFee: (explorerUrl: string) => Promise<number>;
    txUtilsFunctions: () => {
        getRawTransaction: (explorerUrl: string, txid: string) => Promise<any>;
    };
    private signPSBTWithSigner;
    private createNativeSweepPSBT;
    private createUnsignedPSBT;
    private signPSBTWithMethod;
    getEstimateSysTransactionFee: ({ txOptions, isMax, nativeSweep, amount, receivingAddress, feeRate, token, excludedOutpoints, }: {
        amount: number | string;
        feeRate?: number;
        receivingAddress: string;
        token?: {
            guid: string;
            symbol?: string;
        } | null;
        txOptions?: any;
        isMax?: boolean | false;
        nativeSweep?: boolean;
        excludedOutpoints?: readonly ExcludedOutpoint[];
    }) => Promise<{
        grossAmount?: string | undefined;
        recipientAmount?: string | undefined;
        fee: number;
        psbt: any;
    }>;
    private sendSignedTransaction;
    signPSBT: ({ psbt, isTrezor, isLedger, }: {
        psbt: any;
        isTrezor?: boolean;
        isLedger?: boolean;
    }) => Promise<any>;
    sendTransaction: (psbt: any) => Promise<ITxid>;
}
