import { TypedMessage, SignTypedDataVersion, TypedDataV1 } from '@metamask/eth-sig-util';
import { INetwork } from '@sidhujag/sysweb3-network';
import { BigNumber, TransactionResponse } from '../ethers-v6';
import { CustomJsonRpcProvider } from '../providers';
import { IResponseFromSendErcSignedTransaction, ISendSignedErcTransactionProps, IEthereumTransactions, IEvmCancellationOptions, IEvmReplacementOptions, IEvmSendOptions, SimpleTransactionRequest, KeyringAccountType, accountType, IGasParams } from '../types';
import type { LedgerKeyring } from '../ledger';
import type { TrezorKeyring } from '../trezor';
/** Minimal trusted device capabilities used by EVM transaction routing. */
export interface EthereumLedgerSigner {
    evm: Pick<LedgerKeyring['evm'], 'signTypedData' | 'signPersonalMessage' | 'signEVMTransaction'>;
    verifyUtxoAddress: LedgerKeyring['verifyUtxoAddress'];
}
export type EthereumTrezorSigner = Pick<TrezorKeyring, 'signTypedData' | 'signMessage' | 'signEthTransaction' | 'verifyUtxoAddress'>;
export declare class EthereumTransactions<TLedger extends EthereumLedgerSigner | undefined = LedgerKeyring, TTrezor extends EthereumTrezorSigner | undefined = TrezorKeyring> implements IEthereumTransactions {
    private _web3Provider;
    private _web3ProviderKey?;
    trezorSigner: TTrezor;
    ledgerSigner: TLedger;
    private getNetwork;
    private captureSigningContext?;
    private abortController;
    private getDecryptedPrivateKey;
    private gasOverrides;
    private getState;
    constructor(getNetwork: () => INetwork, getDecryptedPrivateKey: (targetAccount?: IEvmReplacementOptions['targetAccount']) => {
        address: string;
        decryptedPrivateKey: string;
    }, getState: () => {
        accounts: {
            HDAccount: accountType;
            Imported: accountType;
            Ledger: accountType;
            Trezor: accountType;
        };
        activeAccountId: number;
        activeAccountType: KeyringAccountType;
        activeNetwork: INetwork;
    }, ledgerSigner: TLedger, trezorSigner: TTrezor, captureSigningContext?: () => () => void);
    private requireLedgerSigner;
    private requireTrezorSigner;
    private assertHardwareSignerAvailable;
    private captureEvmSigningContext;
    get web3Provider(): CustomJsonRpcProvider;
    private ensureProvidersInitialized;
    private isUtxoNetwork;
    signTypedData: (addr: string, typedData: TypedDataV1 | TypedMessage<any>, version: SignTypedDataVersion) => Promise<string>;
    verifyUtxoAddress: (accountIndex: number, currency: string, slip44: number) => Promise<string | undefined>;
    verifyTypedSignature: (data: TypedDataV1 | TypedMessage<any>, signature: string, version: SignTypedDataVersion) => string;
    ethSign: (params: string[]) => Promise<string>;
    signPersonalMessage: (params: string[]) => Promise<string>;
    parsePersonalMessage: (hexMsg: string) => string;
    verifyPersonalMessage: (message: string, sign: string) => string;
    getEncryptedPubKey: () => string;
    decryptMessage: (msgParams: string[]) => string;
    toBigNumber: (aBigNumberish: string | number) => BigNumber;
    private toHex0x;
    private resolveEvmFeeParams;
    getData: ({ contractAddress, receivingAddress, value, }: {
        contractAddress: string;
        receivingAddress: string;
        value: any;
    }) => string;
    getFeeDataWithDynamicMaxPriorityFeePerGas: (provider?: CustomJsonRpcProvider) => Promise<{
        gasPrice: BigNumber;
        maxFeePerGas: BigNumber;
        maxPriorityFeePerGas: BigNumber;
        baseFeePerGas?: undefined;
    } | {
        gasPrice: BigNumber;
        baseFeePerGas: BigNumber;
        maxFeePerGas: BigNumber;
        maxPriorityFeePerGas: BigNumber;
    }>;
    calculateNewGasValues: (oldTxsParams: IGasParams, isForCancel: boolean, isLegacy: boolean) => IGasParams;
    cancelSentTransaction: (txHash: string, isLegacy: boolean | undefined, fallbackNonce: number | undefined, options: IEvmCancellationOptions) => Promise<{
        error?: boolean;
        isCanceled: boolean;
        maximumFee?: string;
        transaction?: TransactionResponse;
    }>;
    sendFormattedTransaction: (params: SimpleTransactionRequest, isLegacy?: boolean, options?: IEvmSendOptions) => Promise<any>;
    private sendFormattedTransactionInternal;
    sendTransactionWithEditedFee: (txHash: string, isLegacy?: boolean, options?: IEvmReplacementOptions) => Promise<{
        maximumFee?: string;
        error?: boolean;
        isSpeedUp: boolean;
        transaction?: TransactionResponse;
        code?: string;
        message?: string;
    }>;
    sendSignedErc20Transaction: ({ receiver, tokenAddress, tokenAmount, isLegacy, maxPriorityFeePerGas, maxFeePerGas, gasPrice, decimals, gasLimit, saveTrezorTx, }: ISendSignedErcTransactionProps) => Promise<IResponseFromSendErcSignedTransaction>;
    sendSignedErc721Transaction: ({ receiver, tokenAddress, tokenId, isLegacy, maxPriorityFeePerGas, maxFeePerGas, gasPrice, gasLimit, }: ISendSignedErcTransactionProps) => Promise<IResponseFromSendErcSignedTransaction>;
    sendSignedErc1155Transaction: ({ receiver, tokenAddress, tokenId, tokenAmount, isLegacy, maxPriorityFeePerGas, maxFeePerGas, gasPrice, gasLimit, }: ISendSignedErcTransactionProps) => Promise<IResponseFromSendErcSignedTransaction>;
    getRecommendedNonce: (address: string) => Promise<number>;
    getFeeByType: (type: string) => Promise<string>;
    getGasLimit: (toAddress: string) => Promise<number>;
    getTxGasLimit: (tx: SimpleTransactionRequest) => Promise<any>;
    getRecommendedGasPrice: (formatted?: boolean) => Promise<string | {
        gwei: string;
        ethers: string;
    }>;
    getBalance: (address: string) => Promise<number>;
    setWeb3Provider(network: INetwork): void;
    importAccount: (mnemonicOrPrivKey: string) => import("./evm-local-signer").EvmLocalAccount;
    setGasOverrides(overrides: {
        minGasLimit?: string | BigNumber;
        minPriorityFee?: string | BigNumber;
        feeMultiplier?: number;
    }): void;
    getGasOverrides(): {
        minGasLimit?: BigNumber;
        minPriorityFee?: BigNumber;
        feeMultiplier?: number;
    };
    getSafeFeeData: (forceLegacy?: boolean) => Promise<{
        gasPrice: BigNumber;
        maxFeePerGas: undefined;
        maxPriorityFeePerGas: undefined;
    } | {
        gasPrice: undefined;
        maxFeePerGas: BigNumber;
        maxPriorityFeePerGas: BigNumber;
    }>;
}
