import { INetworkType } from '@sidhujag/sysweb3-network';
import { IKeyringAccountState } from './types';
export declare const initialActiveHdAccountState: IKeyringAccountState;
export declare const initialActiveImportedAccountState: IKeyringAccountState;
export declare const initialActiveTrezorAccountState: IKeyringAccountState;
export declare const initialActiveLedgerAccountState: IKeyringAccountState;
export declare const initialNetworksState: {
    syscoin: {
        [chainId: number]: import("@sidhujag/sysweb3-network").INetwork;
    };
    ethereum: {
        1: {
            chainId: number;
            url: string;
            label: string;
            default: boolean;
            currency: string;
            explorer: string;
            apiUrl: string;
            slip44: number;
            kind: INetworkType;
        };
        137: {
            chainId: number;
            currency: string;
            default: boolean;
            label: string;
            url: string;
            apiUrl: string;
            explorer: string;
            slip44: number;
            kind: INetworkType;
        };
        80001: {
            chainId: number;
            currency: string;
            default: boolean;
            label: string;
            url: string;
            apiUrl: string;
            explorer: string;
            slip44: number;
            kind: INetworkType;
        };
        57: {
            chainId: number;
            currency: string;
            default: boolean;
            label: string;
            url: string;
            apiUrl: string;
            explorer: string;
            slip44: number;
            kind: INetworkType;
        };
        570: {
            chainId: number;
            currency: string;
            default: boolean;
            label: string;
            url: string;
            apiUrl: string;
            explorer: string;
            slip44: number;
            kind: INetworkType;
        };
        5700: {
            chainId: number;
            currency: string;
            default: boolean;
            label: string;
            url: string;
            apiUrl: string;
            explorer: string;
            slip44: number;
            kind: INetworkType;
        };
    };
};
