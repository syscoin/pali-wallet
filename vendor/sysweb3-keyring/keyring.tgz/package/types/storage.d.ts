export declare const setEncryptedVault: (decryptedVault: any, pwd: string, freshVaultKeys?: {
    salt: string;
}) => Promise<void>;
export declare const getDecryptedVault: (pwd: string, legacyPassword?: string) => Promise<any>;
export { VaultAuthenticationError } from './storage-core';
