export declare function handleStatusCodeError(statusCode: number, errorMessage: string): void;
