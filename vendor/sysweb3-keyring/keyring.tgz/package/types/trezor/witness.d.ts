import { Buffer } from 'buffer';
/** Canonical Bitcoin witness-vector encoding (CompactSize count and lengths). */
export declare const serializeWitness: (witness: readonly Uint8Array[]) => Buffer;
