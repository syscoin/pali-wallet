/**
 * Utility functions for PSBT conversion between Pali and syscoinjs formats
 */
export declare class PsbtUtils {
    /**
     * Import PSBT from Pali's exported format to syscoinjs PSBT object
     * @param psbtFromPali - PSBT data exported from Pali
     * @param network - Optional bitcoinjs network to anchor address/HRP
     * @returns syscoinjs PSBT object
     */
    static fromPali(psbtFromPali: any, network: any): any;
    /**
     * Export syscoinjs PSBT object to Pali's expected format
     * @param psbt - syscoinjs PSBT object
     * @returns PSBT data in Pali's expected format
     */
    static toPali(psbt: any): any;
}
