export declare const fetchBackendAccountCached: (backendUrl: string, xpub: string, options: string) => Promise<any>;
/**
 * Drop in-flight account fetches. Without arguments clears everything;
 * with an xpub only that account's entries are dropped (any backend).
 */
export declare const invalidateBlockbookAccountCache: (xpub?: string) => void;
