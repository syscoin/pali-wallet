import { INetwork } from '@sidhujag/sysweb3-network';
export declare const descriptorChecksum: (value: string) => string;
/** Derive only the single-key public descriptor forms supported by Blockbook. */
export declare const deriveDescriptorAddress: (descriptor: string, network: INetwork, options?: {
    change?: boolean;
    index?: number;
}) => string;
