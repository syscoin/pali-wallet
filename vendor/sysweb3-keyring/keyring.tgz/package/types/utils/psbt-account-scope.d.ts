import { INetwork } from '@sidhujag/sysweb3-network';
import { Psbt } from 'bitcoinjs-lib';
import { KeyringAccountType } from '../types';
export declare const parsePsbtAccountXpub: (xpub: string) => import("bip32").BIP32Interface;
export type PsbtAccountScope = {
    account: {
        address: string;
        xpub: string;
    };
    accountId: number;
    accountType: KeyringAccountType;
    network: INetwork;
};
export declare function createPsbtDerivationGuard(scope: PsbtAccountScope): (path: string) => string;
/** Verify key ownership from public derivation and the actual spent script.
 * Proprietary address metadata is deliberately never an authority here.
 */
export declare function assertPsbtAccountScope(psbt: Psbt, scope: PsbtAccountScope): void;
