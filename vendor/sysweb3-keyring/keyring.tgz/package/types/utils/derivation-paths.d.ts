/**
 * Get coin information by coin shortcut or slip44
 * Priority: 1) Check if slip44=60 (EVM), 2) Check coins.ts (UTXO), 3) Default to unknown
 */
export declare function getCoinInfo(coinShortcut: string, slip44: number): {
    slip44: any;
    segwit: any;
    isEvm: boolean;
};
/**
 * Determine if a coin is EVM-based (Ethereum-like)
 */
export declare function isEvmCoin(coinShortcut: string, slip44: number): boolean;
/**
 * Determine if a coin uses SegWit (BIP84 - m/84')
 */
export declare function isSegwitCoin(coinShortcut: string, slip44: number): boolean;
/**
 * Determine if a coin uses legacy derivation (BIP44 - m/44')
 */
export declare function isLegacyCoin(coinShortcut: string, slip44: number): boolean;
/**
 * Get the appropriate BIP standard for a coin
 */
export declare function getBipStandard(coinShortcut: string, slip44: number): number;
/**
 * Generate derivation path for account level (ending with account index)
 * Example: m/84'/57'/0' for Syscoin account derivation
 */
export declare function getAccountDerivationPath(coinShortcut: string, slip44: number, accountIndex?: number): string;
/**
 * Generate derivation path for address level (full path to specific address)
 * Example: m/84'/57'/0'/0/0 for first address of first Syscoin account
 */
export declare function getAddressDerivationPath(coinShortcut: string, slip44: number, accountIndex?: number, isChangeAddress?: boolean, addressIndex?: number): string;
/**
 * Convert an extended key's version bytes to a target version (e.g., xpub->zpub or tpub->vpub)
 * - Pass targetVersionHex as a 4-byte hex string (e.g., '04b24746' for zpub, '045f1cf6' for vpub)
 */
export declare function convertExtendedKeyVersion(extendedKey: string, targetVersionHex: string): string;
