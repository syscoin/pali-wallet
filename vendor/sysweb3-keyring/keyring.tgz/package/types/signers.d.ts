import { BitcoinNetwork, IPubTypes, INetwork } from '@sidhujag/sysweb3-network';
import { BIP32Interface } from 'bip32';
import type { Psbt } from 'bitcoinjs-lib';
export declare const getSyscoinSigners: ({ mnemonic, rpc, }: ISyscoinSignerParams) => {
    hd: SyscoinHDSigner;
    main: any;
};
export type SyscoinHdAccount = {
    network: BitcoinNetwork;
    networks: {
        mainnet: BitcoinNetwork;
        testnet: BitcoinNetwork;
    };
    pubTypes: IPubTypes;
    zprv: string;
};
export type ISyscoinSignerParams = {
    mnemonic: string;
    rpc: {
        formattedNetwork: INetwork;
        networkConfig?: {
            networks: {
                mainnet: BitcoinNetwork;
                testnet: BitcoinNetwork;
            };
            types: {
                xPubType: IPubTypes;
                zPubType: IPubTypes;
            };
        };
    };
};
export type IMainSignerParams = {
    hd: SyscoinHDSigner;
    network?: BitcoinNetwork;
    url: string;
};
export interface SyscoinHDSigner {
    Signer: {
        SLIP44: number;
        accountIndex: number;
        accounts: any;
        blockbookURL: string;
        changeIndex: number;
        network: BitcoinNetwork;
        networks: {
            mainnet: BitcoinNetwork;
            testnet: BitcoinNetwork;
        };
        password: string | null;
        pubTypes: IPubTypes;
        receivingIndex: number;
        setIndexFlag: number;
    };
    backup: () => void;
    blockbookURL: string;
    createAccount: (bipNum?: number, zprv?: string) => number;
    createAccountAtIndex: (index: number, bipNum?: number, zprv?: string) => number;
    createAddress: (addressIndex: number, isChange: boolean, bipNum?: number) => string;
    createKeypair: (addressIndex: number, isChange: boolean) => BIP32Interface;
    deriveAccount: (index: number, bipNum?: number) => string;
    deriveKeypair: (keypath: string) => BIP32Interface;
    derivePubKey: (keypath: string) => string;
    getAccountXpub: () => string;
    getAddressFromKeypair: (keypair: BIP32Interface) => string;
    getAddressFromPubKey: (pubkey: string) => string;
    getHDPath: (addressIndex: number, isChange: boolean, bipNum?: number) => string;
    getNewReceivingAddress: (skipIncrement?: boolean, bipNum?: number) => Promise<string>;
    node: {
        seed: Buffer;
        coinType: number;
        pubTypes: IPubTypes;
        network: BitcoinNetwork;
    };
    setAccountIndex: (accountIndex: number) => void;
    getRootNode: () => BIP32Interface;
    importMethod: string;
    signPSBT: ({ psbt, isTrezor, isLedger, }: {
        psbt: any;
        isTrezor?: boolean;
        isLedger?: boolean;
    }) => Promise<any>;
    getNewChangeAddress: (skipIncrement?: boolean, bipNum?: number) => Promise<string>;
    restore: (password: string, bipNum?: number) => boolean;
    mnemonicOrZprv: string;
    setLatestIndexesFromXPubTokens: (tokens: any) => void;
    sign: (psbt: Psbt) => Promise<Psbt>;
    getMasterFingerprint: () => Buffer;
}
export type SyscoinMainSigner = {
    Signer: SyscoinHDSigner;
    blockbookURL: string;
    network: BitcoinNetwork;
};
