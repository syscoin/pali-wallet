/** Software-only entry: explicit host storage, no browser/device initialization. */
import { KeyringCore } from './keyring-core';
import type { KeyringStoragePort } from './keyring-core';
declare const softwareHostBrand: unique symbol;
/** Opaque handle minted by createSoftwareKeyringHost; no injectable persistence. */
export interface SoftwareKeyringHost {
    readonly [softwareHostBrand]: true;
}
/** Create once per wallet authority, then share with its per-network keyrings. */
export declare const createSoftwareKeyringHost: (storage: KeyringStoragePort) => SoftwareKeyringHost;
export declare class SoftwareKeyring extends KeyringCore<undefined, undefined> {
    constructor(host: SoftwareKeyringHost);
    /** Software authorities cannot rebind their backing store after creation. */
    setStorage: (client: any) => never;
    /** Sessions may move only through the core's same-authority transfer path. */
    receiveSessionOwnership: (...session: Parameters<KeyringCore["receiveSessionOwnership"]>) => never;
    static createInitialized(host: SoftwareKeyringHost, seed: string, password: string, vaultStateGetter: () => any): Promise<SoftwareKeyring>;
}
export { KeyringAccountType } from './types';
export { INetworkType } from '@sidhujag/sysweb3-network';
export type { INetwork } from '@sidhujag/sysweb3-network';
export type { KeyringStoragePort } from './keyring-core';
export type { IKeyringAccountState } from './types';
