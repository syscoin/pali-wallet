import { BigNumber, JsonRpcProvider, type Networkish } from './ethers-v6';
import type { JsonRpcPayload } from 'ethers/providers';
export declare class RpcResponseIntegrityError extends Error {
    readonly retryable: boolean;
    readonly code = "SYSWEB3_RPC_RESPONSE_INVALID";
    constructor(message?: string, retryable?: boolean);
}
export declare const wrapTransactionReceipt: (receipt: any) => any;
export declare const wrapTransactionResponse: (transaction: any) => any;
declare class BaseProvider extends JsonRpcProvider {
    private isPossibleGetChainId;
    private cooldownTime;
    private rateLimit;
    private requestCount;
    private lastRequestTime;
    private currentChainId;
    private feeDataCache;
    private feeDataPromise;
    private readonly configuredChainId?;
    private chainIdVerificationPromise;
    isInCooldown: boolean;
    errorMessage: any;
    serverHasAnError: boolean;
    signal: AbortSignal;
    _pendingBatchAggregator: NodeJS.Timer | null;
    _pendingBatch: Array<{
        reject: (error: Error) => void;
        request: {
            id: number;
            jsonrpc: '2.0';
            method: string;
            params: Array<any>;
        };
        resolve: (result: any) => void;
    }> | null;
    constructor(signal: AbortSignal, url?: string | {
        url: string;
    }, network?: Networkish);
    private bindMethods;
    private throttledRequest;
    private canMakeRequest;
    verifyConfiguredChainId(): Promise<void>;
    private fetchAndVerifyConfiguredChainId;
    private cooldown;
    private validateRpcResponses;
    private requestRpc;
    _send(payload: JsonRpcPayload | Array<JsonRpcPayload>): Promise<any[]>;
    send: (method: string, params: any[]) => Promise<any>;
    sendBatch(method: string, params: Array<any[]>): Promise<any[]>;
    getGasPrice(): Promise<BigNumber>;
    getFeeData(): Promise<any>;
    private readFeeData;
    private fetchFeeData;
    getBalance(address: string, blockTag?: any): Promise<any>;
    private normalizeLegacyCallRequest;
    call(transaction: any, blockTag?: any): Promise<any>;
    estimateGas(transaction: any): Promise<any>;
    getBlock(blockHashOrBlockTag: any): Promise<any>;
    getTransaction(hash: string): Promise<any>;
    sendTransaction(signedTransaction: string): Promise<any>;
}
export declare class CustomJsonRpcProvider extends BaseProvider {
    constructor(signal: AbortSignal, url?: string | {
        url: string;
    }, network?: Networkish);
}
export {};
