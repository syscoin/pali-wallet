import { HardwareWalletManager } from './hardware-wallet-manager';
import { KeyringCore } from './keyring-core';
import { LedgerKeyring } from './ledger';
import { TrezorKeyring } from './trezor';
import type { IKeyringManager } from './types';
export type { ISysAccount } from './keyring-core';
/** Existing browser entry. Native/software hosts must use the software entry. */
export declare class KeyringManager extends KeyringCore<LedgerKeyring, TrezorKeyring> implements IKeyringManager {
    constructor(sharedHardwareWalletManager?: HardwareWalletManager);
    static createInitialized(seed: string, password: string, vaultStateGetter: () => any): Promise<KeyringManager>;
}
