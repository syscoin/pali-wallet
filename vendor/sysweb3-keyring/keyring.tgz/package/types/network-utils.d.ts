import { INetwork } from '@sidhujag/sysweb3-network';
/**
 * Generate default UTXO networks from coins.ts data
 * This ensures consistency and avoids hardcoded duplicates
 */
export declare function getDefaultUTXONetworks(): {
    [chainId: number]: INetwork;
};
/**
 * Get specific default UTXO networks for backwards compatibility
 */
export declare function getSyscoinUTXOMainnetNetwork(): INetwork;
export declare function getSyscoinUTXOTestnetNetwork(): INetwork;
export declare function getBitcoinMainnetNetwork(): INetwork;
