export declare const DESCRIPTOR = "wpkh(@0/**)";
export declare const RECEIVING_ADDRESS_INDEX = 0;
export declare const WILL_NOT_DISPLAY = false;
