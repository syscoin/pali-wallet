import type { Psbt } from 'bitcoinjs-lib';
/** Enrich public PSBT metadata only. Callers must also enforce account scope. */
export declare function prepareLedgerPsbt(psbt: Psbt, accountXpub: string, accountId: number, currency: string, slip44: number, fingerprint: string): Psbt;
