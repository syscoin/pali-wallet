import Transport from '@ledgerhq/hw-transport';
import SysUtxoClient from './bitcoin_client';
import type { Psbt } from 'bitcoinjs-lib';
import { IEvmMethods, IUTXOMethods } from './types';
import LedgerEthClient from '@ledgerhq/hw-app-eth';
import { HardwareWalletManager } from '../hardware-wallet-manager';
export declare class LedgerKeyring {
    ledgerEVMClient: LedgerEthClient;
    ledgerUtxoClient: SysUtxoClient;
    private hdPath;
    evm: IEvmMethods;
    utxo: IUTXOMethods;
    transport: Transport | null;
    private hardwareWalletManager;
    private walletHmacCache;
    /**
     * @param sharedHardwareWalletManager Optional shared HardwareWalletManager instance.
     *                                     If provided, this will be used instead of creating
     *                                     a new instance. This allows multiple KeyringManagers
     *                                     to share the same Ledger connection.
     */
    constructor(sharedHardwareWalletManager?: HardwareWalletManager);
    /**
     * Ensure Ledger is connected with automatic retry
     * Note: This is automatically called by all operations through executeWithRetry
     * External callers don't need to call this directly
     */
    ensureConnection(): Promise<void>;
    private getUtxoAddress;
    verifyUtxoAddress: (accountIndex: number, currency: string, slip44: number) => Promise<string>;
    private getXpub;
    /**
     * Sign a UTXO message - public method used by transaction classes
     */
    signUtxoMessage: (path: string, message: string) => Promise<string>;
    private signEVMTransaction;
    private signPersonalMessage;
    private sanitizeData;
    private transformTypedData;
    private getEvmAddressAndPubKey;
    private signTypedData;
    private getMasterFingerprint;
    private buildWalletCacheKey;
    private getOrRegisterHmac;
    private setHdPath;
    /**
     * Convert PSBT to Ledger format with retry logic
     */
    convertToLedgerFormat(psbt: Psbt, accountXpub: string, accountId: number, currency: string, slip44: number): Promise<Psbt>;
    /**
     * Execute operation with automatic retry
     */
    private executeWithRetry;
    /**
     * Get hardware wallet status
     */
    getStatus(): import("../hardware-wallet-manager").HardwareWalletStatus | undefined;
    /**
     * Clean up resources
     */
    destroy(): Promise<void>;
}
