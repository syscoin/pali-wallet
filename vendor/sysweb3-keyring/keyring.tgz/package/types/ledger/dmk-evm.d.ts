import { type ContextModule } from '@ledgerhq/context-module';
import { type LedgerEvmHost, type LedgerEvmConfig } from './host-types';
import type { LedgerDmkSession } from './dmk-session';
export type { LedgerBlindSigningIntent, LedgerEvmConfig } from './host-types';
/** No remote metadata, transaction checks, or signing telemetry by default. */
export declare const offlineLedgerContext: ContextModule;
/** EVM facade preserves existing SDK signature formats and performs no broadcast. */
export declare function createLedgerEvmAdapter(session: LedgerDmkSession, config?: LedgerEvmConfig): LedgerEvmHost;
