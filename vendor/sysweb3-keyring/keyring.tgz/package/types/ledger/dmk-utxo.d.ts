import { DeviceExchangeError, type ApduResponse, type Command, type InternalApi } from '@ledgerhq/device-management-kit';
import { type BitcoinAppTransport } from './bitcoin_client/lib/appClient';
import { LedgerDmkSession } from './dmk-session';
import { type LedgerUtxoAccount, type LedgerUtxoHost } from './host-types';
export declare class LedgerProtocolError extends DeviceExchangeError<number> {
    readonly statusCode: number;
    readonly code: string;
    constructor(statusCode: number);
}
/** Preserves the existing Bitcoin/Syscoin APDU contract, including 0xe000. */
export declare class LedgerBitcoinCommand implements Command<Buffer, void, number> {
    private readonly cla;
    private readonly ins;
    private readonly p1;
    private readonly p2;
    private readonly data;
    private readonly acceptedStatusCodes;
    readonly name = "PaliBitcoinProtocol";
    constructor(cla: number, ins: number, p1: number, p2: number, data?: Uint8Array, acceptedStatusCodes?: number[]);
    getApdu(): import("@ledgerhq/device-management-kit").Apdu;
    parseResponse(response: ApduResponse): import("@ledgerhq/device-management-kit").CommandResult<Buffer<ArrayBufferLike>, number>;
}
/** Must be used inside a single DeviceAction; public dmk.sendCommand would requeue. */
export declare function createBitcoinAppTransport(internalApi: InternalApi, assertCurrent: () => void): BitcoinAppTransport;
export declare function ledgerUtxoApp(request: LedgerUtxoAccount): string;
export declare function createLedgerUtxoAdapter(session: LedgerDmkSession): LedgerUtxoHost;
