export declare function checkError(method: string, error: any, params: any): any;
export declare const SYSCOIN_BASIC_FEE = 0.00001;
export declare const ONE_HUNDRED_MILLION = 100000000;
export declare const BIP_84 = 84;
