/** Versioned, public envelope. Application metadata belongs inside the plaintext. */
export interface IEncryptedPrivateRecord {
    ciphertext: string;
    domain: string;
    nonce: string;
    profileId: string;
    recordId: string;
    version: 1;
}
export interface IEncryptPrivateRecordParams {
    domain: string;
    plaintext: Uint8Array;
    recordId: string;
}
export interface IDecryptPrivateRecordParams {
    domain: string;
    envelope: IEncryptedPrivateRecord;
    recordId: string;
}
export declare const MAX_PRIVATE_RECORD_BYTES: number;
export declare const MAX_PRIVATE_RECORD_LABEL_BYTES = 128;
type Guard = () => void;
export declare function privateRecordProfileId(secret: Uint8Array, guard: Guard): Promise<string>;
export declare function encryptPrivateRecordBytes(secret: Uint8Array, params: IEncryptPrivateRecordParams, guard: Guard): Promise<IEncryptedPrivateRecord>;
export declare function decryptPrivateRecordBytes(secret: Uint8Array, params: IDecryptPrivateRecordParams, guard: Guard): Promise<Uint8Array>;
export {};
