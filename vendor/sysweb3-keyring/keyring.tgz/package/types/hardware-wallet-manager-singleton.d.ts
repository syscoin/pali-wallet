import { HardwareWalletManager } from './hardware-wallet-manager';
/**
 * Singleton wrapper for HardwareWalletManager to ensure a single instance
 * is shared across all KeyringManager instances. This prevents "device already open"
 * errors when multiple networks try to connect to the same Ledger device.
 */
declare class HardwareWalletManagerSingleton {
    private static instance;
    /**
     * Get the shared HardwareWalletManager instance
     * Creates one if it doesn't exist
     */
    static getInstance(): HardwareWalletManager;
    /**
     * Reset the singleton instance (useful for testing)
     */
    static resetInstance(): void;
}
export { HardwareWalletManagerSingleton };
