import type { LedgerHost, LedgerEvmConfig } from './ledger/host-types';
export interface LedgerDmkHostConfig extends LedgerEvmConfig {
    /** Platform-owned DMK, allowing a future host to register its own transports. */
    dmk?: object;
}
export declare function createLedgerDmkHost(config?: LedgerDmkHostConfig): LedgerHost;
export type { LedgerEvmConfig, LedgerBlindSigningIntent, LedgerHost, LedgerEvmHost, LedgerUtxoHost, LedgerUtxoAccount, LedgerPartialSignature, LedgerTypedData, LedgerOperationOptions, LedgerProgress, } from './ledger/host-types';
